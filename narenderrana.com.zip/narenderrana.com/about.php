<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="robots" content="" />
<!-- Primary Meta Tags -->
<title>Narender Rana - Mobile App Developer with UI/UX Design | Delhi Based Website Development, React Js Developer</title>
<meta name="title" content="Narender Rana - Mobile App Developer with UI/UX Design | Delhi Based Website Development, React Js Developer">
<meta name="description" content="I’m a UX/UI Designer with over 10 years of experience in conceptualizing and building professional interfaces and interactive websites. Mobile App developer, website designer in delhi with React.js">
<meta name="keywords" content="Narender Rana ui&ux designer, Narender rana website developer Noida delhi NCR, Narender Rana Mobile App Developer Noida Delhi NCRUI UX design freelancer, react js developers noida, freelance web developer, ui ux designer in noida">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://narenderrana.com/about.php">
<meta property="og:title" content="Narender Rana - Mobile App Developer with UI/UX Design | Delhi Based Website Development, React Js Developer">
<meta property="og:description" content="I’m a UX/UI Designer with over 10 years of experience in conceptualizing and building professional interfaces and interactive websites. Mobile App developer, website designer in delhi with React.js">
<meta property="og:image" content="https://scontent.fpat2-1.fna.fbcdn.net/v/t1.6435-9/40330458_1864914193554733_7497282469377343488_n.jpg?_nc_cat=107&ccb=1-3&_nc_sid=174925&_nc_ohc=072aanNEyO0AX_qB4kT&_nc_ht=scontent.fpat2-1.fna&oh=8f0592daf21a994ec11b23617d5f251d&oe=60CEC789">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://narenderrana.com/about.php">
<meta property="twitter:title" content="Narender Rana - Mobile App Developer with UI/UX Design | Delhi Based Website Development, React Js Developer">
<meta property="twitter:description" content="I’m a UX/UI Designer with over 10 years of experience in conceptualizing and building professional interfaces and interactive websites. Mobile App developer, website designer in delhi with React.js">
<meta property="twitter:image" content="https://scontent.fpat2-1.fna.fbcdn.net/v/t1.6435-9/40330458_1864914193554733_7497282469377343488_n.jpg?_nc_cat=107&ccb=1-3&_nc_sid=174925&_nc_ohc=072aanNEyO0AX_qB4kT&_nc_ht=scontent.fpat2-1.fna&oh=8f0592daf21a994ec11b23617d5f251d&oe=60CEC789">

        <!--Favicon-->
        <link rel="shortcut icon" type="image/png" href="media/fav.png"/>
        <!-- Stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
    	<link rel="stylesheet" href="css/animate.css" />
        <link rel="stylesheet" href="css/menu-style.css" />
        <link rel="stylesheet" href="css/lightmode.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/loader.css">
        <!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-55Z8QSB');</script>
        <!-- End Google Tag Manager -->
	</head>
  <body class="no-scroll-y dark-mode">
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-55Z8QSB"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <div id="preloader">
        <div id="ctn-preloader" class="ctn-preloader"> 
            <div class="animation-preloader progress pink">
                <div class="progress-bar" style="width:100%; background:#fff;">
                </div>
            </div>
            <div class="myName">
                <div class="wavy">
                  <span style="--i:1;">N</span>
                  <span style="--i:2;">A</span>
                  <span style="--i:3;">R</span>
                  <span style="--i:4;">E</span>
                  <span style="--i:5;">N</span>
                  <span style="--i:6;">D</span>
                  <span style="--i:7;">E</span>
                  <span style="--i:8;">R</span>
                  &nbsp;
                  <span style="--i:9;">R</span>
                  <span style="--i:10;">A</span>
                  <span style="--i:11;">N</span>
                  <span style="--i:12;">A</span>
                </div>
            </div>
            <div class="progress-value" id="count1"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <!-- header start -->
   <?php include'header.php'; ?>
  
    <div class="scroll-down">
        <a class="down" href="#">Scroll down <span class="arrow-down">→</span></a>
    </div>
  
    <!-- About Section
    ================================================= -->
    <section class="page-content contact-page about-me wow fadeIn position-relative">
        <div class="pagination">About</div>
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="my-photo">
                                <img class="hover-target" src="media/narender.jpg" alt="" title="" />
                            </div>
                        </div>
                        <div class="col-md-9">
                            <h2 class="wow fadeInUp" data-wow-duration="3000ms">
                                Hi, I’m Narender Rana  <span>/</span> <small>THE STORY</small>
                            </h2>
                            <p class="wow fadeInUp" data-wow-duration="3000ms">I’m a UX/UI Designer with over 10 years of experience in conceptualizing and building professional interfaces and interactive websites. I also specialize in branding and identity such as logo design, letterhead and business card, along with providing other graphic design services. </p>
                            <p class="wow fadeInUp" data-wow-duration="3000ms">Even as a child I was fascinated with design. Most of the things I know in the design space are self-taught. While I was learning design tools, I found my new love for programming and multi-media design. And now I am comfortable working on all aspects of design, from ideation to prototype to beautiful UIs and the final product. </p>

                            <div class="my-skills">
                                <h2 class="mb-5 wow fadeInUp" data-wow-duration="3000ms">
                                    Skills <span>/</span> <small>THE TOOLS</small>
                                </h2>
                                <div class="row myskills-list">
                                    <div class="col-md-5">
                                        <p>Figma</p>
                                        <p>Adobe Photoshop</p>
                                        <p>Adobe Illustrator</p>
                                        <p>Adobe InDesign</p>
                                        <p>Adobe XD</p>
                                        <p>Adobe After Effects</p>
                                    </div>
                                    <div class="col-md-4 col-6">
                                        <p>HTML 5</p>
                                        <p>CSS 3</p>
                                        <p>JavaScript</p>
                                        <p>React JS</p>
                                        <p>React Native</p>
                                        <p>Github</p>
                                    </div>
                                    <div class="col-md-3 col-6">
                                        <p>PHP</p>
                                        <p>Wordpress</p>
                                        <p>Drupal</p>
                                        <p>Mysql</p>
                                        <p>MongoDB</p>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="my-skills">
                                <h2 class="mb-5 wow fadeInUp" data-wow-duration="1000ms">
                                    Brands I’ve Worked With <span>/</span> <small>DRUM ROLLS</small>
                                </h2>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="my-skills text-center">
                        <h2 class="mb-4 pb-1 wow fadeInUp" data-wow-duration="2000ms">
                            “If you think good design is expensive, <br/>you should look at the cost of bad design.”
                        </h2>
                        <p class="testi-name">-- Ralf Speth</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="dot-image">
            <ul id="scene" class="scene fill">
                <li class="layer expand-width" data-depth="2">
                    <img src="media/dot-image.png" alt="" title="" class="img-responsive" />
                </li>
            </ul>
        </div>

    </section>

    <?php include'footer.php'; ?>

    <!-- The Modal -->
    <!-- The Modal End -->

    <div class="curser-pointer">
        <div class='cursor' id="cursor"></div>
        <div class='cursor2' id="cursor2"></div>
        <div class='cursor3' id="cursor3"></div>
    </div>

    <!-- ========== Light & Dark Options ========== -->
    <div class="day-night">
        <div class="night active" data-dsn-theme="dark">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <rect x="12.3" y="23.5" width="2.6" height="1"></rect>
                <rect x="16.1" y="15.3" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -6.8871 16.5732)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="12.3" width="1" height="2.6"></rect>
                <rect x="30.1" y="16.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -2.5145 27.0538)" width="2.6"
                    height="1"></rect>
                <rect x="33.1" y="23.5" width="2.6" height="1"></rect>
                <rect x="30.9" y="30.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -12.9952 31.4264)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="33.1" width="1" height="2.6"></rect>
                <rect x="15.3" y="30.9" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -17.3677 20.9457)" width="2.6"
                    height="1"></rect>
                <path
                    d="M24,18.7c-2.9,0-5.3,2.4-5.3,5.3s2.4,5.3,5.3,5.3s5.3-2.4,5.3-5.3S26.9,18.7,24,18.7z M24,28.3c-2.4,0-4.3-1.9-4.3-4.3s1.9-4.3,4.3-4.3s4.3,1.9,4.3,4.3S26.4,28.3,24,28.3z">
                </path>
            </svg>
        </div>
        <div class="moon" data-dsn-theme="night">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <path
                    d="M24,33.9c-5.4,0-9.9-4.4-9.9-9.9c0-4.3,2.7-8,6.8-9.4l0.8-0.3l-0.1,0.9c-0.2,0.6-0.2,1.3-0.2,1.9c0,5.2,4.3,9.5,9.5,9.5c0.6,0,1.3-0.1,1.9-0.2l0.8-0.2L33.3,27C32,31.1,28.3,33.9,24,33.9z M20.4,15.9c-3.2,1.4-5.3,4.5-5.3,8.1c0,4.9,4,8.9,8.9,8.9c3.6,0,6.7-2.1,8.1-5.3c-0.4,0-0.8,0.1-1.3,0.1c-5.8,0-10.5-4.7-10.5-10.5C20.4,16.7,20.4,16.3,20.4,15.9z">
                </path>
            </svg>
        </div>
    </div>
    <!-- ========== End Light & Dark Options ========== -->
    
    <!-- Scripts
    ================================================= -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menu-script.js"></script>
    <script src="js/parallax.hover.js"></script>
    <script src='js/gsap.min.js'></script>
    <script src='js/ScrollTrigger.min.js'></script>
    <script  src="js/rvscript.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/canvas.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>