<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="robots" content="" />
		<!-- Primary Meta Tags -->
<title>Website Development, Branding, UI/UX | Portfolio - Narender Rana</title>
<meta name="title" content="Website Development, Branding, UI/UX | Portfolio - Narender Rana">
<meta name="description" content="I have developed websites and mobile apps for Quantum Ventures, Pan Villas, DBC, Melrose, Bond Fitness, Digipanda, etc">
<meta name="keywords" content="ui ux designer work, narendra rana ui ux designer portfolio, best website developers in noida">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://narenderrana.com/work.php">
<meta property="og:title" content="Website Development, Branding, UI/UX | Portfolio - Narender Rana">
<meta property="og:description" content="I have developed websites and mobile apps for Quantum Ventures, Pan Villas, DBC, Melrose, Bond Fitness, Digipanda, etc">
<meta property="og:image" content="https://narenderrana.com/media/port/8.png">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://narenderrana.com/work.php">
<meta property="twitter:title" content="Website Development, Branding, UI/UX | Portfolio - Narender Rana">
<meta property="twitter:description" content="I have developed websites and mobile apps for Quantum Ventures, Pan Villas, DBC, Melrose, Bond Fitness, Digipanda, etc">
<meta property="twitter:image" content="https://narenderrana.com/media/port/8.png">

        <!--Favicon-->
        <link rel="shortcut icon" type="image/png" href="media/fav.png"/>
        <!-- Stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
    	<link rel="stylesheet" href="css/animate.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css" />
        <link rel="stylesheet" href="css/menu-style.css" />
        <link rel="stylesheet" href="css/lightmode.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/loader.css">
		<script src='https://www.google.com/recaptcha/api.js' async defer></script>

        <style type="text/css">
            .js-tilt-glare {
                max-width: 590px;
            }
            .tab-content>.tab-pane{
                width: 100%;
            }
        </style>
        <!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-55Z8QSB');</script>
        <!-- End Google Tag Manager -->
	</head>
    <body class="no-scroll-y dark-mode">
        
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-55Z8QSB"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <div id="preloader">
        <div id="ctn-preloader" class="ctn-preloader"> 
            <div class="animation-preloader progress pink">
                <div class="progress-bar" style="width:100%; background:#fff;">
                </div>
            </div>
            <div class="myName">
                <div class="wavy">
                  <span style="--i:1;">N</span>
                  <span style="--i:2;">A</span>
                  <span style="--i:3;">R</span>
                  <span style="--i:4;">E</span>
                  <span style="--i:5;">N</span>
                  <span style="--i:6;">D</span>
                  <span style="--i:7;">E</span>
                  <span style="--i:8;">R</span>
                  &nbsp;
                  <span style="--i:9;">R</span>
                  <span style="--i:10;">A</span>
                  <span style="--i:11;">N</span>
                  <span style="--i:12;">A</span>
                </div>
            </div>
            <div class="progress-value" id="count1"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <!-- header start -->
    <?php include'header.php'; ?>
  
    <div class="scroll-down">
        <a class="down" href="#">Scroll down <span class="arrow-down">→</span></a>
    </div>
  
    <!-- About Section
    ================================================= -->
    <section class="page-content contact-page about-me wow fadeIn position-relative">
        <div class="pagination">Projects</div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="wow fadeInUp mb-0 pb-0" data-wow-duration="3000ms">
                        Portfolio <span>/</span> <small>MY WORK</small>
                    </h2>
                </div>
            </div>
            <div class="row">
                 <div class="col-lg-10 offset-lg-1">
                    <div class="filter-tab">
                        <div class="portfolio-menu">
                            <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="one-tab" data-toggle="tab" href="#one" role="tab" aria-controls="One" aria-selected="true">Websites</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="two-tab" data-toggle="tab" href="#two" role="tab" aria-controls="Two" aria-selected="false">BRANDING</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="three-tab" data-toggle="tab" href="#three" role="tab" aria-controls="Three" aria-selected="false">UI/UX</a>
                                </li>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" id="four-tab" data-toggle="tab" href="#four" role="tab" aria-controls="Four" aria-selected="false">PHOTOGRAPHY</a>
                                </li> -->
                            </ul>
                        </div>
                        <div class="tab-content portfolio-item row work-content mywork" id="myTabContent">
                            <div class="tab-pane fade show active p-3" id="one" role="tabpanel" aria-labelledby="one-tab">

                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">Back TO Source website development</h2>
                                        <a target="_blank" href="https://back2source.in/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                    <div class="col-lg-8 col-md-8 order1">
                                        
                                            <div class="reveal boxHover">
                                                <img class="img-fluid" src="media/port/1.png" alt="">
                                                <div class="box-content">
                                                    <ul class="icon">
                                                        <li><a target="_blank" href="https://back2source.in/"><i class="fa fa-link"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        
                                    </div>
                                </div> 
                                <div class="row item align-items-center">
                                    <div class="col-lg-8 col-md-8">
                                        
                                        <div class="reveal boxHover">
                                            <img class="img-fluid" src="media/port/2.png" alt="">
                                            <div class="box-content">
                                                <ul class="icon">
                                                    <li><a target="_blank" href="https://greenaxs.com/"><i class="fa fa-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                      
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">Green Axs website development</h2>
                                        <a target="_blank" href="https://greenaxs.com/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">Rekoop website development</h2>
                                        <a target="_blank" href="https://rekoop.pet/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                    <div class="lap col-lg-8 col-md-8 order1">
                                       
                                        <div class="reveal boxHover">
                                            <img class="img-fluid" src="media/port/3.png" alt="">
                                            <div class="box-content">
                                                <ul class="icon">
                                                    <li><a target="_blank" href="https://rekoop.pet/"><i class="fa fa-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                      
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="lap col-lg-8 col-md-8">
                                        
                                        <div class="reveal boxHover">
                                            <img class="img-fluid" src="media/port/4.png" alt="">
                                            <div class="box-content">
                                                <ul class="icon">
                                                    <li><a target="_blank" href="https://melrosecapital.ae/"><i class="fa fa-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">Melrose website development</h2>
                                        <a target="_blank" href="https://melrosecapital.ae/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">MEME Marketing website development</h2>
                                        <a target="_blank" href="https://mememarketing.in/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                    <div class="col-lg-8 col-md-8 order1">
                                       
                                        <div class="reveal boxHover">
                                            <img class="img-fluid" src="media/port/5.png" alt="">
                                            <div class="box-content">
                                                <ul class="icon">
                                                    <li><a target="_blank" href="https://mememarketing.in/"><i class="fa fa-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                     
                                    </div>
                                </div> 
                                <div class="row item align-items-center">
                                    <div class="col-lg-8 col-md-8">
                                        
                                        <div class="reveal boxHover">
                                            <img class="img-fluid" src="media/port/6.png" alt="">
                                            <div class="box-content">
                                                <ul class="icon">
                                                    <li><a target="_blank" href="https://bond-fitness.com/"><i class="fa fa-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                      
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">BOND Fitness website development</h2>
                                        <a target="_blank" href="https://bond-fitness.com/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">DBC website development</h2>
                                        <a target="_blank" href="https://digitalbusinesscards.com.au/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                    <div class="lap col-lg-8 col-md-8 order1">
                                        
                                            <div class="reveal boxHover">
                                                <img class="img-fluid" src="media/port/7.png" alt="">
                                                <div class="box-content">
                                                    <ul class="icon">
                                                        <li><a target="_blank" href="https://digitalbusinesscards.com.au/"><i class="fa fa-link"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                       
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="lap col-lg-8 col-md-8">
                                       
                                        <div class="reveal boxHover">
                                            <img class="img-fluid" src="media/port/8.png" alt="">
                                            <div class="box-content">
                                                <ul class="icon">
                                                    <li><a target="_blank" href="https://digipanda.co.in/"><i class="fa fa-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                       
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">Digipanda website development</h2>
                                        <a target="_blank" href="https://digipanda.co.in/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">Quantum Ventures development</h2>
                                        <a target="_blank" href="https://quantumvent.com/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                    <div class="lap col-lg-8 col-md-8 order1">
                                       
                                        <div class="reveal boxHover">
                                            <img class="img-fluid" src="media/port/9.png" alt="">
                                            <div class="box-content">
                                                <ul class="icon">
                                                    <li><a target="_blank" href="https://quantumvent.com/"><i class="fa fa-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="lap col-lg-8 col-md-8">
                                        
                                        <div class="reveal boxHover">
                                            <img class="img-fluid" src="media/port/10.png" alt="">
                                            <div class="box-content">
                                                <ul class="icon">
                                                    <li><a target="_blank" href="https://panvilas.in/"><i class="fa fa-link"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                       
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">Pan Vilas website development</h2>
                                        <a target="_blank" href="https://panvilas.in/" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                </div>  

                            </div>

                            <div class="tab-pane fade p-3" id="two" role="tabpanel" aria-labelledby="two-tab">
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">Kiyaan <br/> logo design</h2>
                                    </div>
                                    <div class="col-lg-8 col-md-8 order1">
                                        <a href="media/logo/1.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                                        <div class="reveal">
                                            <img class="img-fluid" src="media/logo/1.jpg" alt="">
                                        </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-8 col-md-8">
                                        <a href="media/logo/2.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                                        <div class="reveal">
                                            <img class="img-fluid" src="media/logo/2.jpg" alt="">
                                        </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">Digipanda Consulting <br/> logo design</h2>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">Meditasi <br/> logo design</h2>
                                    </div>
                                    <div class="col-lg-8 col-md-8 order1">
                                        <a href="media/logo/3.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                                        <div class="reveal">
                                            <img class="img-fluid" src="media/logo/3.jpg" alt="">
                                        </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-8 col-md-8">
                                        <a href="media/logo/4.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                                        <div class="reveal">
                                            <img class="img-fluid" src="media/logo/4.jpg" alt="">
                                        </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">Kalkine <br/> logo design</h2>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">MEUTE VENTURES <br/> logo design</h2>
                                    </div>
                                    <div class="col-lg-8 col-md-8 order1">
                                        <a href="media/logo/5.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                                        <div class="reveal">
                                            <img class="img-fluid" src="media/logo/5.jpg" alt="">
                                        </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-8 col-md-8">
                                        <a href="media/logo/6.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                                        <div class="reveal">
                                            <img class="img-fluid" src="media/logo/6.jpg" alt="">
                                        </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">Sailax Media <br/> Logo design</h2>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">DBC <br/>logo design</h2>
                                    </div>
                                    <div class="col-lg-8 col-md-8 order1">
                                        <a href="media/logo/7.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                                        <div class="reveal">
                                            <img class="img-fluid" src="media/logo/7.jpg" alt="">
                                        </div>
                                        </a>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade p-3" id="three" role="tabpanel" aria-labelledby="three-tab">
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">DBC app <br/> UI & UX</h2>
                                        <a href="https://play.google.com/store/apps/details?id=com.modern.dvc" target="_blank" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                    <div class="lap col-lg-8 col-md-8 order1">
                                        <a href="https://play.google.com/store/apps/details?id=com.modern.dvc" target="_blank">
                                            <div class="reveal">
                                                <img class="img-fluid" src="media/uiux/1.jpg" alt="">
                                            </div>
                                        </a>
                                    </div>
                                </div> 
                                <div class="row item align-items-center">
                                    <div class="lap col-lg-8 col-md-8 order1">
                                        <a href="#" target="_blank">
                                            <div class="reveal">
                                                <img class="img-fluid" src="media/uiux/2.jpg" alt="">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">USHA Silai app UI & UX</h2>
                                        <a href="#" target="_blank" class="more-btn mb-0">Launching Soon &nbsp; →</a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">SIA app <br/> UI & UX</h2>
                                        <a href="#" target="_blank" class="more-btn mb-0">Launching Soon &nbsp; →</a>
                                    </div>
                                    <div class="lap col-lg-8 col-md-8 order1">
                                        <a href="#" target="_blank">
                                            <div class="reveal">
                                                <img class="img-fluid" src="media/uiux/3.jpg" alt="">
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="lap col-lg-8 col-md-8 order1">
                                        <a href="#" target="_blank">
                                            <div class="reveal">
                                                <img class="img-fluid" src="media/uiux/4.jpg" alt="">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">Sailax Media <br/> UI & UX </h2>
                                        <a href="#" target="_blank" class="more-btn mb-0">Launching Soon &nbsp; →</a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="col-lg-4 col-md-4 order2">
                                        <h2 class="wow fadeInUp mb-0">Kiyaan app <br/> UI & UX</h2>
                                        <a href="https://play.google.com/store/apps/details?id=com.kiyaancollection" target="_blank" class="more-btn mb-0">View Project &nbsp; →</a>
                                    </div>
                                    <div class="lap col-lg-8 col-md-8 order1">
                                        <a href="https://play.google.com/store/apps/details?id=com.kiyaancollection" target="_blank">
                                            <div class="reveal">
                                                <img class="img-fluid" src="media/uiux/5.jpg" alt="">
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="row item align-items-center">
                                    <div class="lap col-lg-8 col-md-8">
                                        <a href="#" target="_blank">
                                            <div class="reveal">
                                                <img class="img-fluid" src="media/uiux/6.jpg" alt="">
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <h2 class="wow fadeInUp mb-0">SAMSUNG <br/> community app <br/> UI & UX </h2>
                                        <a href="#" target="_blank" class="more-btn mb-0">Launching Soon &nbsp; →</a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

     <?php include'footer.php'; ?>
    <!-- The Modal -->
    <!-- The Modal End -->

    <div class="curser-pointer">
        <div class='cursor' id="cursor"></div>
        <div class='cursor2' id="cursor2"></div>
        <div class='cursor3' id="cursor3"></div>
    </div>

    <!-- ========== Light & Dark Options ========== -->
    <div class="day-night">
        <div class="night active" data-dsn-theme="dark">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <rect x="12.3" y="23.5" width="2.6" height="1"></rect>
                <rect x="16.1" y="15.3" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -6.8871 16.5732)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="12.3" width="1" height="2.6"></rect>
                <rect x="30.1" y="16.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -2.5145 27.0538)" width="2.6"
                    height="1"></rect>
                <rect x="33.1" y="23.5" width="2.6" height="1"></rect>
                <rect x="30.9" y="30.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -12.9952 31.4264)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="33.1" width="1" height="2.6"></rect>
                <rect x="15.3" y="30.9" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -17.3677 20.9457)" width="2.6"
                    height="1"></rect>
                <path
                    d="M24,18.7c-2.9,0-5.3,2.4-5.3,5.3s2.4,5.3,5.3,5.3s5.3-2.4,5.3-5.3S26.9,18.7,24,18.7z M24,28.3c-2.4,0-4.3-1.9-4.3-4.3s1.9-4.3,4.3-4.3s4.3,1.9,4.3,4.3S26.4,28.3,24,28.3z">
                </path>
            </svg>
        </div>
        <div class="moon" data-dsn-theme="night">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <path
                    d="M24,33.9c-5.4,0-9.9-4.4-9.9-9.9c0-4.3,2.7-8,6.8-9.4l0.8-0.3l-0.1,0.9c-0.2,0.6-0.2,1.3-0.2,1.9c0,5.2,4.3,9.5,9.5,9.5c0.6,0,1.3-0.1,1.9-0.2l0.8-0.2L33.3,27C32,31.1,28.3,33.9,24,33.9z M20.4,15.9c-3.2,1.4-5.3,4.5-5.3,8.1c0,4.9,4,8.9,8.9,8.9c3.6,0,6.7-2.1,8.1-5.3c-0.4,0-0.8,0.1-1.3,0.1c-5.8,0-10.5-4.7-10.5-10.5C20.4,16.7,20.4,16.3,20.4,15.9z">
                </path>
            </svg>
        </div>
    </div>
    <!-- ========== End Light & Dark Options ========== -->
    
    <!-- Scripts
    ================================================= -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>
    <script src="js/menu-script.js"></script>
    <script src='js/gsap.min.js'></script>
    <script src='js/ScrollTrigger.min.js'></script>
    <script  src="js/rvscript.js"></script>
    <!-- <script src='js/tilt.jquery.js'></script> -->
    <script src="js/wow.min.js"></script>
    <script src="js/canvas.js"></script>
    <script src="js/script.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            var popup_btn = $('.popup-btn');
            popup_btn.magnificPopup({
                type : 'image',
                gallery : {
                    enabled : true
                }
            });
        });
    </script>
    <!-- <script type="text/javascript">
        ( function( $ ) {

            "use strict";

          $(".reveal").tilt({
            maxTilt: 15,
            perspective: 1400,
            easing: "cubic-bezier(.03,.98,.52,.99)",
            speed: 1200,
            glare: true,
            maxGlare: 0.2,
          });
          
        }( jQuery ) );
    </script> -->
  </body>
</html>