
<footer class="wow fadeIn">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="row">
                        <div class="col-md-5">
                            <h2 class="wow fadeInUp" data-wow-duration="2000ms">Get in touch</h2>
                            <p class="wow fadeInUp" data-wow-duration="2000ms">Feel free to contact me for any kind of <br/> digital project or information</p>
                        </div>
                        <div class="col-md-7">
                            <a href="mailto:hello@narenderrana.com"><h2 class="wow fadeInUp" data-wow-duration="2000ms">hello@narenderrana.com</h2></a>
                            <div class="row">
                                <div class="col-md-4">
                                    <a class="wow fadeInUp" href="tel:+91 9891292049" data-wow-duration="2000ms"><p>T : +91 9891 292 049</p></a>
                                    <ul class="social-linksf">
                                        <li><a target="_blank" href="https://www.linkedin.com/in/narender-rana-61b0b619/"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a target="_blank" href="https://www.instagram.com/neelrana89/"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="https://www.facebook.com/rananarender.it" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                    </ul>
                                </div>
                                <div class="col-md-8">
                                    <p class="wow fadeInUp" data-wow-duration="1000ms"><strong>Let’s Collaborate</strong> </p>
                                    <p class="wow fadeInUp" data-wow-duration="2000ms">I’m always looking to work on innovative and exciting projects. Drop me an email, and let’s get going.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <ul class="footer-links wow fadeInUp">
                        <li><a href="javascript:void(0)" class="form-toggle">Brief <i class="ml-2 fa fa-cloud-upload" aria-hidden="true"></i></a> /</li>
                        <li><a href="work.php">Portfolio</a> /</li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <div class="form-wrapper">
        <div class="close">
          <img src="media/close.png" alt="" title="" />
        </div>
        <div class="Brief-div">
            <h2>Upload Your Brief</h2>
            <div class="form-div">
<form action="mail.php" method="post" enctype="multipart/form-data" autocomplete="off">
                    <div class="form-group">
                        <input type="name" name="name" class="form-control" required placeholder="Name*">
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" class="form-control" required placeholder="Email*">
                    </div>
                    <div class="form-group">
                        <div class="file-upload-wrapper" data-text="Select your file!">
						<input type="file" name="file" class="form-control file-upload-field" required />
                           <!-- <input name="file-upload-field" type="file" name="file" class="form-control file-upload-field" >-->
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" placeholder="Message*" name="message" required rows="3"></textarea>
                    </div>
                     <div class="g-recaptcha" data-sitekey="6LeNonAgAAAAAA-XjYe4-adQAAwLF-14M8rgpfSv"></div>
<!-- <label><strong>Enter Captcha:</strong></label><br />
<input type="text" required name="captcha" />
<p><br /><img src="captcha.php?rand=<?php echo rand(); ?>" id='captcha_image1'></p>
<p>Can't read the image? <a href='javascript: refreshCaptcha1();'>click here</a> to refresh</p> -->
                               
                    <div class="text-left">

                        <?php function isMobile() {
                            return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
                        } ?>

                        <input type="hidden" name="utm_term" value="<?php echo isset($_GET['utm_term']) ? $_GET['utm_term'] : '' ?>">
                        <input type="hidden" name="utm_source" value="<?php echo isset($_GET['utm_source']) ? $_GET['utm_source'] : '' ?>">
                        <input type="hidden" name="utm_medium" value="<?php echo isset($_GET['utm_medium']) ? $_GET['utm_medium'] : '' ?>">
                        <input type="hidden" name="utm_campaign" value="<?php echo isset($_GET['utm_campaign']) ? $_GET['utm_campaign'] : '' ?>">
                        <input type="hidden" name="last_url" value="<?php isset($_SERVER['HTTP_REFERER'])? $_SERVER['HTTP_REFERER']:''; ?>">

                        <input type="hidden" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">

                        <input type="hidden" name="device" value="<?php echo isMobile()? 'mobile':'desktop'; ?>">
                        

                        <button type="submit" name="uploadbutton" class="btn btn-warning btn-block mybtn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<script>
//Refresh Captcha
function refreshCaptcha1(){
    var img = document.images['captcha_image1'];
    img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
</script>