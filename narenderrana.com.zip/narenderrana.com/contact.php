<?php
session_start();
$status = ''; 
require 'digiFunction.php';
if(isset($_POST['submit'])){
$status = checkCaptcha($_POST['g-recaptcha-response']);
$name =$_POST['name']; // required
$subject1=$_POST['subject'];//required
$email = $_POST['email']; // optional
$message1 =$_POST['message']; // optional
require 'vendor/autoload.php'; // If you're using Composer (recommended)
$message = '
Name : '.$name.' <br/>
Email : '.$email.' <br/>
Subject : '.$subject1.' <br/>
Message : '.$message1.' <br/>
';
// if ( isset($_POST['captchanew']) && ($_POST['captchanew']!="") ){
// // Validation: Checking entered captcha code with the generated captcha code
// if(strcasecmp($_SESSION['captchanew'], $_POST['captchanew']) != 0){
if(!$status['success']){
// Note: the captcha code is compared case insensitively.
// if you want case sensitive match, update the check above to strcmp()
echo "<script>
alert('Entered captcha code does not match! Kindly try again');
window.location.href='contact.php';
</script>";
}else{

//save data into database
$curl = curl_init();

$postData = array(
    'action' => 'narendrarana',
    'name'   => $_POST['name'],
    'email'   => $_POST['email'],
    'subject'   => $_POST['subject'],
    'message'   => $_POST['message'],
    'device'   => $_POST['device'],
    'ip'   => $_POST['ip'],
    'utm_term'   => $_POST['utm_term'],
    'utm_source'   => $_POST['utm_source'],
    'utm_medium'   => $_POST['utm_medium'],
    'utm_campaign'   => $_POST['utm_campaign'],
    'last_url'   => $_POST['last_url']
);

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://digipanda.co.in/seo-company-noida/lms/Api.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => $postData,
));

$response = curl_exec($curl);
curl_close($curl);


$API_key = "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";
$nemail = new \SendGrid\Mail\Mail();
$nemail->setFrom("info@digipanda.co.in", "Narender Rana’s Contact query");
$nemail->setSubject("Query for Narender Rana’s Personal work");
$nemail->addTo("narender@digipanda.co.in");
//$nemail->addTo("jyoti@digipanda.co.in");
//$nemail->addCc("jyoti9901@gmail.com");
$nemail->addContent("text/plain", "and easy to do anywhere, even with PHP");
$nemail->addContent(
    "text/html", $message
);
$sendgrid = new \SendGrid($API_key);
if($sendgrid->send($nemail));
{
	header( "Location: thankyou.php");
} 
}
// }
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="robots" content="" />
<!-- Primary Meta Tags -->
<title>Delhi Based Mobile App Developer, Graphic Designer | Website Designer - Narender Rana</title>
<meta name="title" content="Delhi Based Mobile App Developer, Graphic Designer | Website Designer - Narender Rana">
<meta name="description" content="Let's get going. Contact for all aspects of designs, UI UX designs, React.js, Mobile app development, website development.">
<meta name="keywords" content="best website developers in noida, top ui ux designers india">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://narenderrana.com/contact.php">
<meta property="og:title" content="Delhi Based Mobile App Developer, Graphic Designer | Website Designer - Narender Rana">
<meta property="og:description" content="Let's get going. Contact for all aspects of designs, UI UX designs, React.js, Mobile app development, website development.">
<meta property="og:image" content="https://narenderrana.com/media/intro-layer-3.png">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://narenderrana.com/contact.php">
<meta property="twitter:title" content="Delhi Based Mobile App Developer, Graphic Designer | Website Designer - Narender Rana">
<meta property="twitter:description" content="Let's get going. Contact for all aspects of designs, UI UX designs, React.js, Mobile app development, website development.">
<meta property="twitter:image" content="https://narenderrana.com/media/intro-layer-3.png">

        <!--Favicon-->
        <link rel="shortcut icon" type="image/png" href="media/fav.png"/>
        <!-- Stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
    	<link rel="stylesheet" href="css/animate.css" />
        <link rel="stylesheet" href="css/menu-style.css" />
        <link rel="stylesheet" href="css/lightmode.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/loader.css">
		<script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-55Z8QSB');</script>
        <!-- End Google Tag Manager -->

	</head>
  <body class="no-scroll-y dark-mode">

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-55Z8QSB"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <div id="preloader">
        <div id="ctn-preloader" class="ctn-preloader"> 
            <div class="animation-preloader progress pink">
                <div class="progress-bar" style="width:100%; background:#fff;">
                </div>
            </div>
            <div class="myName">
                <div class="wavy">
                  <span style="--i:1;">N</span>
                  <span style="--i:2;">A</span>
                  <span style="--i:3;">R</span>
                  <span style="--i:4;">E</span>
                  <span style="--i:5;">N</span>
                  <span style="--i:6;">D</span>
                  <span style="--i:7;">E</span>
                  <span style="--i:8;">R</span>
                  &nbsp;
                  <span style="--i:9;">R</span>
                  <span style="--i:10;">A</span>
                  <span style="--i:11;">N</span>
                  <span style="--i:12;">A</span>
                </div>
            </div>
            <div class="progress-value" id="count1"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <!-- header start -->
    <?php include'header.php'; ?>
  
    <!-- Contact Section
    ================================================= -->
    <section class="page-content contact-page wow fadeIn">
        <div class="pagination">
            Contact
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <h2 class="wow fadeInUp mb-5 name" data-wow-duration="2000ms">Let’s Collaborate</h2>
                    <p class="wow fadeInUp" data-wow-duration="3000ms">I’m always eager to collaborate in the design space. Let’s get in touch. </p>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-8 offset-md-2">
                    <div class="Brief-div w-100">
                        <div class="form-div w-100">
                            <form method="POST" autocomplete="off">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" required placeholder="Name*">
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control" required placeholder="Email*">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="subject" required placeholder="Subject*">
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" name="message" placeholder="Message*" required rows="3"></textarea>
                                </div>
                                 <!-- <label><strong>Enter Captcha:</strong></label><br />
<input type="text" class="form-control" required name="captchanew" />
<p><br /><img src="captcha1.php?rand=<?php echo rand(); ?>" id='captcha_image'></p>
<p>Can't read the image? <a href='javascript: refreshCaptcha();'>click here</a> to refresh</p> -->

                        <div class="g-recaptcha" data-sitekey="6LeNonAgAAAAAA-XjYe4-adQAAwLF-14M8rgpfSv"></div>
                                <div class="text-left">

                                <?php function isMobile2() {
                                    return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
                                } ?>

                                <input type="hidden" name="utm_term" value="<?php echo isset($_GET['utm_term']) ? $_GET['utm_term'] : '' ?>">
                                <input type="hidden" name="utm_source" value="<?php echo isset($_GET['utm_source']) ? $_GET['utm_source'] : '' ?>">
                                <input type="hidden" name="utm_medium" value="<?php echo isset($_GET['utm_medium']) ? $_GET['utm_medium'] : '' ?>">
                                <input type="hidden" name="utm_campaign" value="<?php echo isset($_GET['utm_campaign']) ? $_GET['utm_campaign'] : '' ?>">
                                <input type="hidden" name="last_url" value="<?php isset($_SERVER['HTTP_REFERER'])? $_SERVER['HTTP_REFERER']:''; ?>">

                                <input type="hidden" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">

                                <input type="hidden" name="device" value="<?php echo isMobile2()? 'mobile':'desktop'; ?>">

                                    <button type="submit" name="submit" class="btn btn-warning btn-block mybtn">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php'; ?>
<script>
//Refresh Captcha
function refreshCaptcha(){
    var img = document.images['captcha_image'];
    img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
</script>
    <!-- The Modal -->
    <!-- The Modal End -->

    <div class="curser-pointer">
        <div class='cursor' id="cursor"></div>
        <div class='cursor2' id="cursor2"></div>
        <div class='cursor3' id="cursor3"></div>
    </div>

    <!-- ========== Light & Dark Options ========== -->
    <div class="day-night">
        <div class="night active" data-dsn-theme="dark">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <rect x="12.3" y="23.5" width="2.6" height="1"></rect>
                <rect x="16.1" y="15.3" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -6.8871 16.5732)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="12.3" width="1" height="2.6"></rect>
                <rect x="30.1" y="16.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -2.5145 27.0538)" width="2.6"
                    height="1"></rect>
                <rect x="33.1" y="23.5" width="2.6" height="1"></rect>
                <rect x="30.9" y="30.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -12.9952 31.4264)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="33.1" width="1" height="2.6"></rect>
                <rect x="15.3" y="30.9" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -17.3677 20.9457)" width="2.6"
                    height="1"></rect>
                <path
                    d="M24,18.7c-2.9,0-5.3,2.4-5.3,5.3s2.4,5.3,5.3,5.3s5.3-2.4,5.3-5.3S26.9,18.7,24,18.7z M24,28.3c-2.4,0-4.3-1.9-4.3-4.3s1.9-4.3,4.3-4.3s4.3,1.9,4.3,4.3S26.4,28.3,24,28.3z">
                </path>
            </svg>
        </div>
        <div class="moon" data-dsn-theme="night">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <path
                    d="M24,33.9c-5.4,0-9.9-4.4-9.9-9.9c0-4.3,2.7-8,6.8-9.4l0.8-0.3l-0.1,0.9c-0.2,0.6-0.2,1.3-0.2,1.9c0,5.2,4.3,9.5,9.5,9.5c0.6,0,1.3-0.1,1.9-0.2l0.8-0.2L33.3,27C32,31.1,28.3,33.9,24,33.9z M20.4,15.9c-3.2,1.4-5.3,4.5-5.3,8.1c0,4.9,4,8.9,8.9,8.9c3.6,0,6.7-2.1,8.1-5.3c-0.4,0-0.8,0.1-1.3,0.1c-5.8,0-10.5-4.7-10.5-10.5C20.4,16.7,20.4,16.3,20.4,15.9z">
                </path>
            </svg>
        </div>
    </div>
    <!-- ========== End Light & Dark Options ========== -->
    
    <!-- Scripts
    ================================================= -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menu-script.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/canvas.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>