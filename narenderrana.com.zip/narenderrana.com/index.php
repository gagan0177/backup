<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<meta name="robots" content="" />
<title>Narender Rana : UI & UX Designer, Crafting Designs That People Love!</title>
<meta name="title" content="Narender Rana : UI & UX Designer, Crafting Designs That People Love!">
<meta name="description" content="UI UX designer, React Js, website developer. I work on all type of designs from ideation to prototype to beautiful UI designs, react Js and website development.">
<meta name="keywords" content="ui designer and ux designer,  ui ux designer in delhi ncr, user centric website designer in new delhi, freelancing ui ux designers, react js developers india">
<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://narenderrana.com/">
<meta property="og:title" content="Narender Rana : UI & UX Designer, Crafting Designs That People Love!">
<meta property="og:description" content="UI UX designer, React Js, website developer. I work on all type of designs from ideation to prototype to beautiful UI designs, react Js and website development.">
<meta property="og:image" content="https://narenderrana.com/media/narender.jpg">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://narenderrana.com/">
<meta property="twitter:title" content="Narender Rana : UI & UX Designer, Crafting Designs That People Love!">
<meta property="twitter:description" content="UI UX designer, React Js, website developer. I work on all type of designs from ideation to prototype to beautiful UI designs, react Js and website development.">
<meta property="twitter:image" content="https://narenderrana.com/media/narender.jpg">

        <!--Favicon-->
        <link rel="shortcut icon" type="image/png" href="media/fav.png"/>
        <!-- Stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.min.css"/>
    	<link rel="stylesheet" href="css/animate.css"/>
        <link rel="stylesheet" href="css/menu-style.css" />
        <link rel="stylesheet" href="css/lightmode.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/loader.css">
	

        <!-- Google Tag Manager -->
        <script async>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-55Z8QSB');</script>
        <!-- End Google Tag Manager -->

	</head>
  <body class="no-scroll-y dark-mode">

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-55Z8QSB"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <div id="preloader">
        <div id="ctn-preloader" class="ctn-preloader"> 
            <div class="animation-preloader progress pink">
                <div class="progress-bar" style="width:100%; background:#fff;">
                </div>
            </div>
            <div class="myName">
                <div class="wavy">
                  <span style="--i:1;">N</span>
                  <span style="--i:2;">A</span>
                  <span style="--i:3;">R</span>
                  <span style="--i:4;">E</span>
                  <span style="--i:5;">N</span>
                  <span style="--i:6;">D</span>
                  <span style="--i:7;">E</span>
                  <span style="--i:8;">R</span>
                  &nbsp;
                  <span style="--i:9;">R</span>
                  <span style="--i:10;">A</span>
                  <span style="--i:11;">N</span>
                  <span style="--i:12;">A</span>
                </div>
            </div>
            <div class="progress-value" id="count1"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <!-- header start -->
<?php include'header.php'; ?>
  
    <!-- Intro Section
    ================================================= -->
    <div class="layerFadeIn"></div>
    <section id="intro" class="wow fadeIn">
      <div class="overflow-h">
        <div class="container-fluid p-0">
          <ul id="scene" class="scene fill">
            <li class="layer expand-width" data-depth="0.15">
                <img class="logo-white" src="media/intro-layer-1.png" alt="" class="img-responsive" />
                <img class="logo-dark" src="media/intro-lightmode-layer-1.png" alt="" class="img-responsive">
            </li>
            <li class="layer expand-width"><img src="media/intro-layer-2.png" alt="" class="img-responsive" /></li>
            <li class="layer expand-width zindex1" data-depth="0.40">
                <img data-wow-duration="5000ms" class="wow fadeInRight" src="media/intro-layer-3.png" alt="" class="img-responsive" />
            </li>
            <li class="layer expand-width" data-depth="0.55"><img src="media/intro-layer-4.png" alt="" class="img-responsive" /></li>
            <li class="layer expand-width" data-depth="0.65">
              <div class="my-info" data-parallax='{"y": 100}'>
                <h2 class="name hover-target wow fadeInUp" data-wow-duration="4000ms"><!-- New Delhi-based experienced designer, crafting user-centric designs. --> <!-- Makes technology work better through design.-->
                    Code. Create. Conquer
                </h2>
                <p class="pehragraph_txt" wow fadeInUp" data-wow-duration="5000ms">
                Crafting Digital Excellence as<br/>a Full Stack Developer
                </p>
                <a href="work.php" class="more-btn wow fadeInUp" data-wow-duration="4000ms">See my work &nbsp; →</a>
                <ul class="social-links wow fadeInUp" data-wow-duration="5000ms">
                    <li><a target="_blank" href="https://www.facebook.com/rananarender.it">Facebook</a></li>
                    <li><a target="_blank" href="https://www.linkedin.com/in/narender-rana-61b0b619/">Linkedin</a></li>
                    <li><a target="_blank" href="https://www.instagram.com/neelrana89/">Instagram</a></li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
        <div class="liquid-row"><canvas id="liquid"></canvas></div>
      </div>
      <div class="scroll-down">
        <a class="down" href="#">Scroll down <span class="arrow-down">→</span></a>
      </div>
    </section>

    <section class="up whatido page-content wow fadeIn">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h2 class="wow fadeInUp" data-wow-duration="2000ms">What I do</h2>
                </div>
                <div class="col-md-5">
                    <p class="wow fadeInUp" data-wow-duration="3000ms">I turn amazing ideas into beautiful and useful digital products. And I see each project as a new and valuable addition to solving user problems. Here’s a list of services I can help you with:</p>
                    <ul class="wow fadeInUp" data-wow-duration="4000ms">
                        <li><a href="javascript:void(0)"><sup>01</sup> Website Development</a></li>
                        <li><a href="javascript:void(0)"><sup>02</sup> Landing page</a></li>
                        <li><a href="javascript:void(0)"><sup>03</sup> Online Store</a></li>
                        <li><a href="javascript:void(0)"><sup>04</sup> Mobile App Development</a></li>
                        <li><a href="javascript:void(0)"><sup>05</sup> Branding</a></li>
                        <li><a href="javascript:void(0)"><sup>06</sup> Digital Marketing</a></li>
                        <li><a href="javascript:void(0)"><sup>07</sup> SEO</a></li>
                        <li><a href="javascript:void(0)"><sup>08</sup> MEME Marketing</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <small class="wow fadeInUp d-block" data-wow-duration="4000ms">For the last 10 years, I have been helping businesses expand their capacity for impact. </small>
                </div>
            </div>
        </div>
    </section>

    <section class="mywork page-content wow fadeIn">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="wow fadeInUp">Crafted With Love.</h2>
                    <p class="wow fadeInUp">Check out some of my most loved work pieces.</p>
                </div>
            </div>
            <div class="row mt-5 pt-4">
                <div class="col-lg-10 offset-lg-1">
                    <div class="row align-items-center">
                        <div class="col-md-4 order2">
                            <h2 class="wow fadeInUp">Back TO Source website development</h2>
                            <a target="_blank" href="https://back2source.in/" class="more-btn">View Project &nbsp; →</a>
                        </div>
                        <div class="col-md-8 order1">
                            <div class="reveal boxHover">
                                <img src="media/port/port11.jpg" alt="" title="" />
                                <div class="box-content">
                                    <ul class="icon">
                                        <li><a target="_blank" href="https://back2source.in/"><i class="fa fa-link"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row align-items-center mt-5 pt-3">
                        <div class="col-md-8">
                            <div class="reveal boxHover">
                                <img src="media/port/port12.jpg" alt="" title="" />
                                <div class="box-content">
                                    <ul class="icon">
                                        <li><a target="_blank" href="https://greenaxs.com/"><i class="fa fa-link"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-right">
                            <h2 class="wow fadeInUp">Green Axs website development</h2>
                            <a target="_blank" href="https://greenaxs.com/" class="more-btn">View Project &nbsp; →</a>
                        </div>
                    </div>
                    <div class="row align-items-center mt-5 pt-3">
                        <div class="col-md-4 order2">
                            <h2 class="wow fadeInUp">Rekoop website development</h2>
                            <a target="_blank" href="https://rekoop.pet/" class="more-btn">View Project &nbsp; →</a>
                        </div>
                        <div class="col-md-8 order1">
                            <div class="reveal boxHover">
                                <img src="media/port/port13.jpg" alt="" title="" />
                                <div class="box-content">
                                    <ul class="icon">
                                        <li><a target="_blank" href="https://rekoop.pet/"><i class="fa fa-link"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row align-items-center mt-5 pt-3">
                        <div class="col-md-8">
                            <div class="reveal boxHover">
                                <img src="media/port/port14.jpg" alt="" title="" />
                                <div class="box-content">
                                    <ul class="icon">
                                        <li><a target="_blank" href="https://melrosecapital.ae/"><i class="fa fa-link"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-right">
                            <h2 class="wow fadeInUp">Melrose website development</h2>
                            <a target="_blank" href="https://melrosecapital.ae/" class="more-btn">View Project &nbsp; →</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row pt-5">
                <div class="col-md-12 text-center">
                    <a href="work.php" class="more-btn">view all projects &nbsp; →</a>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php'; ?>
    <!-- The Modal -->
    <!-- The Modal End -->

    <div class="curser-pointer">
        <div class='cursor' id="cursor"></div>
        <div class='cursor2' id="cursor2"></div>
        <div class='cursor3' id="cursor3"></div>
    </div>

    <!-- ========== Light & Dark Options ========== -->
    <div class="day-night">
        <div class="night active" data-dsn-theme="dark">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <rect x="12.3" y="23.5" width="2.6" height="1"></rect>
                <rect x="16.1" y="15.3" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -6.8871 16.5732)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="12.3" width="1" height="2.6"></rect>
                <rect x="30.1" y="16.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -2.5145 27.0538)" width="2.6"
                    height="1"></rect>
                <rect x="33.1" y="23.5" width="2.6" height="1"></rect>
                <rect x="30.9" y="30.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -12.9952 31.4264)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="33.1" width="1" height="2.6"></rect>
                <rect x="15.3" y="30.9" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -17.3677 20.9457)" width="2.6"
                    height="1"></rect>
                <path
                    d="M24,18.7c-2.9,0-5.3,2.4-5.3,5.3s2.4,5.3,5.3,5.3s5.3-2.4,5.3-5.3S26.9,18.7,24,18.7z M24,28.3c-2.4,0-4.3-1.9-4.3-4.3s1.9-4.3,4.3-4.3s4.3,1.9,4.3,4.3S26.4,28.3,24,28.3z">
                </path>
            </svg>
        </div>
        <div class="moon" data-dsn-theme="night">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <path
                    d="M24,33.9c-5.4,0-9.9-4.4-9.9-9.9c0-4.3,2.7-8,6.8-9.4l0.8-0.3l-0.1,0.9c-0.2,0.6-0.2,1.3-0.2,1.9c0,5.2,4.3,9.5,9.5,9.5c0.6,0,1.3-0.1,1.9-0.2l0.8-0.2L33.3,27C32,31.1,28.3,33.9,24,33.9z M20.4,15.9c-3.2,1.4-5.3,4.5-5.3,8.1c0,4.9,4,8.9,8.9,8.9c3.6,0,6.7-2.1,8.1-5.3c-0.4,0-0.8,0.1-1.3,0.1c-5.8,0-10.5-4.7-10.5-10.5C20.4,16.7,20.4,16.3,20.4,15.9z">
                </path>
            </svg>
        </div>
    </div>
    <!-- ========== End Light & Dark Options ========== -->
    
    <!-- Scripts
    ================================================= -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menu-script.js"></script>
    <script src="js/parallax.hover.js"></script>
    <script src='js/gsap.min.js'></script>
    <script src='js/ScrollTrigger.min.js'></script>
    <script  src="js/rvscript.js"></script>
    <!-- <script src='js/tilt.jquery.js'></script> -->
    <script src="js/wow.min.js"></script>
    <script src="js/canvas.js"></script>
    <script src="js/script.js"></script>
 <!--    <script type="text/javascript">
        ( function( $ ) {

            "use strict";

          $(".reveal").tilt({
            maxTilt: 15,
            perspective: 1400,
            easing: "cubic-bezier(.03,.98,.52,.99)",
            speed: 1200,
            glare: true,
            maxGlare: 0.2,
          });
          
        }( jQuery ) );
    </script> -->
  </body>
</html>