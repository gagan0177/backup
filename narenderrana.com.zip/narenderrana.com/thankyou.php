<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="" />
        <meta name="keywords" content="" />
        <meta name="robots" content="" />
        <title>Thank You</title>
        <!--Favicon-->
        <link rel="shortcut icon" type="image/png" href="media/fav.png"/>
        <!-- Stylesheets -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        <link rel="stylesheet" href="css/animate.css" />
        <link rel="stylesheet" href="css/menu-style.css" />
        <link rel="stylesheet" href="css/lightmode.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/loader.css">
        <style type="text/css">
            .layerFadeIn, #intro, .overflow-h{
                height: 100vh;
                min-height: 100vh;
            }
            ul#scene li .my-info {
                position: absolute;
                top: 23%;
                left: 0;
                margin: auto;
                text-align: center;
                max-width: 550px;
                right: 0;
            }
            body.light-mode h5{
                color: #666;
            }
        </style>
		
		<!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-55Z8QSB');</script>
        <!-- End Google Tag Manager -->
		
    </head>
  <body class="no-scroll-y dark-mode">

<!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-55Z8QSB"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- header start -->
    <?php include'header.php'; ?>
  
    <!-- Intro Section
    ================================================= -->
    <div class="layerFadeIn"></div>
    <section id="intro" class="wow fadeIn">
      <div class="overflow-h">
        <div class="container-fluid p-0">
          <ul id="scene" class="scene fill">
            <li class="layer expand-width" data-depth="0.15">
                <img style="opacity: 0;" class="logo-white" src="media/intro-layer-1.png" alt="" class="img-responsive" />
                <img style="opacity: 0;" class="logo-dark" src="media/intro-lightmode-layer-1.png" alt="" class="img-responsive">
            </li>
            <li class="layer expand-width"><img style="opacity: 0;" src="media/intro-layer-2.png" alt="" class="img-responsive" /></li>
            <li class="layer expand-width" data-depth="0.65">
              <div class="my-info" data-parallax='{"y": 100}'>
                <h2 class="name hover-target wow fadeInUp" data-wow-duration="4000ms">Thank you for getting in touch! </h2>
                <h5 class="mt-4 name hover-target wow fadeInUp" data-wow-duration="4000ms">I have received your message and I'll get back to you within 24 hours.</h5>
                <a href="work.php" class="more-btn wow fadeInUp" data-wow-duration="4000ms">See my works &nbsp; →</a>
              </div>
            </li>
          </ul>
        </div>
        <div class="liquid-row"><canvas id="liquid"></canvas></div>
      </div>
    </section>


    <div class="curser-pointer">
        <div class='cursor' id="cursor"></div>
        <div class='cursor2' id="cursor2"></div>
        <div class='cursor3' id="cursor3"></div>
    </div>

    <!-- ========== Light & Dark Options ========== -->
    <div class="day-night">
        <div class="night active" data-dsn-theme="dark">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <rect x="12.3" y="23.5" width="2.6" height="1"></rect>
                <rect x="16.1" y="15.3" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -6.8871 16.5732)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="12.3" width="1" height="2.6"></rect>
                <rect x="30.1" y="16.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -2.5145 27.0538)" width="2.6"
                    height="1"></rect>
                <rect x="33.1" y="23.5" width="2.6" height="1"></rect>
                <rect x="30.9" y="30.1" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -12.9952 31.4264)" width="1"
                    height="2.6"></rect>
                <rect x="23.5" y="33.1" width="1" height="2.6"></rect>
                <rect x="15.3" y="30.9" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -17.3677 20.9457)" width="2.6"
                    height="1"></rect>
                <path
                    d="M24,18.7c-2.9,0-5.3,2.4-5.3,5.3s2.4,5.3,5.3,5.3s5.3-2.4,5.3-5.3S26.9,18.7,24,18.7z M24,28.3c-2.4,0-4.3-1.9-4.3-4.3s1.9-4.3,4.3-4.3s4.3,1.9,4.3,4.3S26.4,28.3,24,28.3z">
                </path>
            </svg>
        </div>
        <div class="moon" data-dsn-theme="night">
            <svg width="48" height="48" viewBox="0 0 48 48">
                <path
                    d="M24,33.9c-5.4,0-9.9-4.4-9.9-9.9c0-4.3,2.7-8,6.8-9.4l0.8-0.3l-0.1,0.9c-0.2,0.6-0.2,1.3-0.2,1.9c0,5.2,4.3,9.5,9.5,9.5c0.6,0,1.3-0.1,1.9-0.2l0.8-0.2L33.3,27C32,31.1,28.3,33.9,24,33.9z M20.4,15.9c-3.2,1.4-5.3,4.5-5.3,8.1c0,4.9,4,8.9,8.9,8.9c3.6,0,6.7-2.1,8.1-5.3c-0.4,0-0.8,0.1-1.3,0.1c-5.8,0-10.5-4.7-10.5-10.5C20.4,16.7,20.4,16.3,20.4,15.9z">
                </path>
            </svg>
        </div>
    </div>
    <!-- ========== End Light & Dark Options ========== -->
    
    <!-- Scripts
    ================================================= -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menu-script.js"></script>
    <script src="js/parallax.hover.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/canvas.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>