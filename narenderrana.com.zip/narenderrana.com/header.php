<script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <header class="cd-header">
        <div class="header-wrapper">
            <div class="logo-wrap">
                <a href="index.php" class="hover-target">
                    <img width="65" class="logo-white" src="media/logo.svg" alt="" />
                    <img width="65" class="logo-dark" src="media/logo-dark.svg" alt="" />
                </a>
            </div>
            <div class="nav-but-wrap">
                <div class="menu-icon hover-target">
                    <span class="menu-icon__line menu-icon__line-left"></span>
                    <span class="menu-icon__line"></span>
                    <span class="menu-icon__line menu-icon__line-right"></span>
                </div>                  
            </div>                  
        </div>              
    </header>

    <div class="nav">
        <div class="nav__content">
            <ul class="nav__list">
                <li class="nav__list-item"><a href="work.php" class="hover-target">Portfolio</a></li>
                <li class="nav__list-item"><a href="about.php" class="hover-target">about</a></li>
                <li class="nav__list-item"><a href="blogs.php" class="hover-target">blogs</a></li>
                <li class="nav__list-item"><a href="contact.php" class="hover-target">contact</a></li>
            </ul>
        </div>
    </div>