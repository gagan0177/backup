<?php

function checkCaptcha($captcha) // Google Captcha Function
{
    $secret = '6LeNonAgAAAAALW5x3ijeFnVBFaP084I5ggCnIn4';
    $url="https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$captcha;
    // $url="https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$captcha."&remoteip=".$ip;
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    $output = curl_exec($ch); 
    curl_close($ch);      
    $status= json_decode($output, true);
    return $status;
}