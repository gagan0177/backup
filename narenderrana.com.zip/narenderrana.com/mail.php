<?php
session_start();
$status = ''; 
require 'digiFunction.php';
if(isset($_POST['uploadbutton'])){
// 	if ( isset($_POST['captcha']) && ($_POST['captcha']!="") ){
// // Validation: Checking entered captcha code with the generated captcha code
// if(strcasecmp($_SESSION['captcha'], $_POST['captcha']) != 0){
    $status = checkCaptcha($_POST['g-recaptcha-response']);
    if(!$status['success']){
// Note: the captcha code is compared case insensitively.
// if you want case sensitive match, update the check above to strcmp()
echo "<script>
alert('Entered captcha code does not match! Kindly try again');
window.location.href='index.php';
</script>";
}else{
$name =$_POST['name']; // required
$email = $_POST['email']; // optional
$message1 =$_POST['message']; // optional
require 'vendor/autoload.php'; // If you're using Composer (recommended)
$message = '
Name : '.$name.' <br/>
Email : '.$email.' <br/>
Message : '.$message1.' <br/>
';
 
$targetDir = "uploads/";
$fileName = basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
 $file_size = $_FILES['file']['size'];
 if (($file_size > 2097152)){      
       	echo "<script>
alert('File too large. File must be less than 2 megabytes.');
window.location.href='index.php';
</script>";
    } else {
move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath);
$API_key = "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";
$nemail = new \SendGrid\Mail\Mail();
$nemail->setFrom("info@digipanda.co.in", "Narender Rana’s brief query");
$nemail->setSubject("Query for Narender Rana’s Personal work");
$nemail->addTo("narender@digipanda.co.in");
// $nemail->addTo("aman@digipanda.co.in");
$nemail->addContent("text/plain", "and easy to do anywhere, even with PHP");
$nemail->addContent(
    "text/html", $message
);
$file_encoded = base64_encode(file_get_contents('uploads/'.$fileName.''));
$nemail->addAttachment(
   $file_encoded,
   'application/'.$fileType.'',
   $fileName,
   "attachment"
);

//save data into database
$curl = curl_init();

$postData = array(
    'page' => 'Brief',
    'action' => 'narendrarana',
    'name'   => $_POST['name'],
    'email'   => $_POST['email'],
    'file'     => 'https://narenderrana.com/'.$targetFilePath,
    'device'   => $_POST['device'],
    'ip'   => $_POST['ip'],
    'utm_term'   => $_POST['utm_term'],
    'utm_source'   => $_POST['utm_source'],
    'utm_medium'   => $_POST['utm_medium'],
    'utm_campaign'   => $_POST['utm_campaign'],
    'last_url'   => $_POST['last_url']
);


//http://localhost/lms/lms/Api.php

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://digipanda.co.in/seo-company-noida/lms/Api.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => $postData,
));

$response = curl_exec($curl);
curl_close($curl);

$sendgrid = new \SendGrid($API_key);
if($sendgrid->send($nemail));
{
	header( "Location: thankyou.php");
} 
	}
}
	// }	
}

?>