
$(function() {
  "use strict";


     $(".share-btn").click(function(){
        $(".share-btn").toggleClass("active")
        $("ul").toggleClass("active")
       })

    /*---animation wow js---*/
    new WOW().init();
    
    
});

