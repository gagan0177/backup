<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>MEME Marketing</title>
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
  <link href="css/bootstrap.min.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
   <link rel="stylesheet" href="css/animate.css"> 
  <script src="https://kit.fontawesome.com/9ec80a7684.js" crossorigin="anonymous"></script>
  
  <!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '628309212759682');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=628309212759682&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<style type="text/css">
  #thankyou-section{
    padding-top: 75px;
    padding-bottom: 20px;
  }
  #thankyou-section h2 {
    margin-bottom: 0em;
    /* border: 2px solid red; */
    color: #320073;
    text-align: center;
    font-size: 38px;
    /* margin: 0 auto; */
    font-family: myFirstFont;
    padding-bottom: 140px;
    padding-top: 40PX;
}
#thankyou-section h2 span {
    color: #fd00a3;
}
</style>
</head>

<body>


<header class="header-defaul clearfix">
  <div class="container-fluid px-5">
    <nav class="navbar navbar-expand-xl navbar-light bg-light">
      <a class="navbar-brand" href="#">
        <img width="130" src="images/logo.png" alt="" />
      </a>
      <div class="" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link HoverStyle01"  data-toggle="modal" data-target="#formmodal">Contact Us</a></li>
          </ul>
        </div>
      </nav>
    </nav>
  </div>
</header>
  
  

  <!-- backgroundbg-cricket section start here..  -->
  <section id="thankyou-section">
    <h2 class="wow fadeInUp">We received your message and our team has already started working on it. <br>
       <span>Thank you for contacting us. You’re helping us make DigiPanda better!</span> </h2>



   
  </section>
  <!-- backgroundbg-cricket section End here..  -->




 







  <footer class="wow fadeInUp">
    <div class="container">
      <div class="row footer-outer">
        <div class="col-lg-5 col-md-5 col-12 footer-inner-left">
          <div style="margin: 0px 40px 0px;">
            <h2 class="wow fadeInUp">Contact Address</h2>
            <p class="wow fadeInUp">D-111, Floor No. 1, Sector 63, Noida, India</p>

            <h2 class="wow fadeInUp">Contact Number</h2>
            <p class="wow fadeInUp"><a href="+91 9599565161">+91 9599565161</a></p>

            <h2 class="wow fadeInUp">Email Address</h2>
            <p class="wow fadeInUp"><a href="mailto:xoxo@mememarketing.in">xoxo@mememarketing.in</a></p>

            <a target="_lank" href="https://www.facebook.com/mememarketingxoxo"><i class="fa-brands fa-facebook-f footer-icon" style="color: #ffffff"></i></a>
            <a target="_lank" href="https://www.instagram.com/mememarketingxoxo/"><i class="fa-brands fa-instagram footer-icon" style="color: #ffffff"></i></a>
            <a target="_lank" href="https://www.linkedin.com/showcase/xoxo-meme-marketing/"><i class="fa-brands fa-linkedin-in footer-icon" style="color: #ffffff"></i></a>
          </div>

        </div>

        <div class="col-lg-3 col-md-3 col-12 footer-inner-centre">
            <h2 class="wow fadeInUp">LINKS</h2>
            <!--<p><a href="https://mememarketing.in/blogs.php" target="_blank">Blogs</a></p>-->
            <p><a data-toggle="modal" data-target="#formmodal">Contact Us</a></p>
        </div>

        <div class="col-lg-4 col-md-4 col-12 footer-inner-right">
          <div>
            <h2 class="wow fadeInUp">Newsletter</h2>
            <p>Get your newsletter here</p>

            <form action="">
              <input type="mailto:" placeholder="Email" value="Email" required />
              <input type="submit" value="Submit" />
            </form>
          </div>
        </div>

        <span class="footer-background-icon">
          <img src="./images/footer/footershape right.png" alt="" />
          <img src="./images/footer/footerEllipse .png" alt="" />
          <!-- <img src="./images/footer/footershapeleft.png" alt="" /> -->
        </span>
      </div>
    </div>
    <div class="copyright">
        <div class="container">
            <div class="col-lg-12 copyright-1">
              <p class="">© 2023 2023 MEME MARKETING</p>
            </div>
        </div>
    </div>
  </footer>


<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script defer src="js/popper.min.js"></script>
<script defer src="js/bootstrap.min.js"></script>
<script defer src="js/wow.min.js"></script> 
<script defer src="js/script.js"></script>


</html>


