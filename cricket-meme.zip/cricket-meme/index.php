<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>MEME Marketing</title>
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
  <link href="css/bootstrap.min.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
   <link rel="stylesheet" href="css/animate.css"> 
  <script src="https://kit.fontawesome.com/9ec80a7684.js" crossorigin="anonymous"></script>
  
  <!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '628309212759682');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=628309212759682&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<style>
  #formmodal .modal-header {
    display: unset;
    padding: 12px 15px;
}
div#formmodal h5#exampleModalLabel {
  color: #f2069e;
  font-size: 25px;
    text-align: center;
/*    font-size: 20px;*/
    font-weight: 700;
}
#formmodal .form-group .form-control {
    height: auto;
    padding: 8px 10px;
    border-radius: 4px;
}
#formmodal .form-group {
    margin-bottom: 10px;
}
#formmodal .form-group textarea#message-3 {
    height: 80px;
}
#price-coin .price-coin-outer .price-coin-inner-right button{
  outline: none;
}
.get-a-quick-quote button{
  outline: none;
}
.modal-header .close {
  outline: none;
   margin-top: -30px;
    background: #000;
    color: #fff;
    border-radius: 22px;
    line-height: 20px;
    width: 25px;
    height: 25px;
    padding: 0;
    opacity: .7;
    margin-right: 0px;
}
.close span{
      margin-top: -7px;
    align-items: center;
    display: flex;
    justify-content: center;
}
/*.btn-color {
    color: #fff;
    border-color: #86c443;
    background-color: #86c443;
}*/
/*.btn-color:hover, .btn-color:active, .btn-color:focus {
    color: #fff;
}*/
.mdi{
  font-style: normal !important;
    font-weight: normal !important;
    font-variant: normal !important;
    text-transform: none !important;
    speak: none;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.btn {
    width: unset;
    border-radius: 25px;
    padding: 0 30px;
    height: 48px;
    line-height: 46px;
    text-transform: uppercase;
    font-size: 14px!important;
    -webkit-transition: all .3s ease;
    transition: all .3s ease;
    font-weight: 400;
    font-family: 'Source Sans Pro', sans-serif;
    color: #fff;
    background:linear-gradient(to bottom right, rgb(50 0 113 / 40%), #FC00A1);
}
a.callToaction {
    background: #320071;
    padding: 5px;
    border-radius: 50%;
    border: 4px solid #320071;
    cursor: pointer;
    width: 45px;
    height: 42px;
    line-height: 19px;
    position: fixed;
    bottom: 10px;
    right: 15px;
    z-index: 9999;
}
.shakeAni {
    animation: shake 1s ease infinite;
    transform-origin: 50% 50%;
    max-width: 100%;
}
  @media(max-width: 349px){
    .navbar-light .navbar-nav li:last-child .nav-link
    {
    padding: 10px 20px;
   }
  }


@keyframes shake{
  10%, 90% {
    transform: translate3d(-1px, 0, 0);
}
20%, 80% {
    transform: translate3d(2px, 0, 0);
}
30%, 50%, 70% {
    transform: translate3d(-4px, 0, 0);
}
40%, 60% {
    transform: translate3d(4px, 0, 0);
}
}
</style>
</head>

<body>
  <!--<header class="header-defaul clearfix">-->
  <!--  <div class="container">-->
  <!--    <div class="header_row position-relative">-->
  <!--        <div class="logo">-->
  <!--          <a href="/">-->
  <!--            <img class="" src="images/logo.png" alt="" />-->
  <!--          </a>-->
  <!--        </div>-->
  <!--        <div class="navigation">-->
  <!--          <div class="btn">-->
  <!--            <span class="fas fa-bars"></span>-->
  <!--          </div>-->
  <!--        </div>-->
  <!--          <nav class="sidebar">-->
  <!--            <ul>-->
  <!--              <li class="active"><a href="#">Home</a></li>-->
        
  <!--              <li><a href="#">Portfolio</a></li>-->
  <!--              <li><a href="#">Overview</a></li>-->
  <!--            </ul>-->
  <!--          </nav>-->
  <!--    </div>-->
  <!--  </div>-->
  <!--</header>-->

<header class="header-defaul clearfix">
  <div class="container-fluid px-5">
    <nav class="navbar navbar-expand-xl navbar-light bg-light">
      <a class="navbar-brand" href="#">
        <img width="130" src="images/logo.png" alt="" />
      </a>
      <div class="" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link HoverStyle01"  data-toggle="modal" data-target="#formmodal">Contact Us</a></li>
          </ul>
        </div>
      </nav>
    </nav>
  </div>
</header>
  
  



<!-- <header class="header-defaul clearfix">
  <div class="container-fluid px-5">
    <nav class="navbar navbar-expand-xl navbar-light bg-light">
      <a class="navbar-brand" href="#">
        <img width="130" src="images/logo.png" alt="" />
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span><i class="fas fa-bars" aria-hidden="true"></i></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto"> -->
          <!--<li class="nav-item"><a class="nav-link" href="social-media-marketing-services.php">Social Media</a></li>-->
          <!--<li class="nav-item"><a class="nav-link" href="influencer-marketing.php">Influencer Marketing</a></li>-->
          <!--<li class="nav-item"><a class="nav-link" href="orm.php">ORM</a></li>-->
          <!--<li class="nav-item"><a class="nav-link" href="roadblock-marketing.php">Road Block</a></li>-->
          <!--<li class="nav-item"><a class="nav-link" href="https://mememarketing.in/blogs.php" target="_blank">Blogs</a></li>-->
          <!-- <li class="nav-item">
            <a class="nav-link HoverStyle01"  data-toggle="modal" data-target="#formmodal">Contact Us</a></li>
          </ul>
        </div>
      </nav>
    </div>
</header> -->

  
  
   

   <section class="banner-head site_banner">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 offset-lg-1 col-12 d-flex">
                <div class="center-side"  data-wow-duration="4s">
                    <div class="center-img">
                        <img class="wow fadeIn spark" src="images/banner/spark.png" alt="" />
                    </div>
                    <div class="dse2">
                        <h6 class="wow fadeIn get-content font-italic">Get Your <span class="font-weight-bold">Meme Game</span> On for the <span class="font-weight-bold">Cricket World Cup</span></h6>
                        <!--<h2 class="wow fadeIn hit-content">Hit Those Sixes of Virality</h2>-->
                        <img width="550" class="wow zoomIn mt-3" src="images/banner/b_text.png" alt="" />
                        <div class="dse3">
                        <a class="wow fadeIn lets-meme grow-rotate btn-style500" data-toggle="modal" data-target="#formmodal">Fix a Chat with Us</a>
                      </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-12"> 
            <div class="right-side"  data-wow-duration="4s">
                <div class="dse4 wow zoomInDown">
                  <img class="cloud" src="images/banner/cloud.png" alt="" />
                  <h2 class="dekha-content">Dekha kya <span class="font-weight-bold"> meme maarat hai</span></h2> 
                </div>
                <div class="dse5">
                    <img class="amir-khan" class="wow fadeInRight amir-khan" src="images/banner/amir.png" alt="" />
                    <div class="face">
                        <img class="wow fadeInRight amir-khan2" src="images/banner/amir1.png" alt="" />
                        <div class="eye1"></div>
                        <div class="eye2"></div>
                    </div>
                  
                </div>
            </div>
        </div>
        </div>
    </div>
    <div class="ball_c wow pulse ripple" data-wow-duration="4s">
      <div class="bal">
        <img class="wow fadeIn big-ball" src="images/banner/left-layer.png" alt="" />
      </div>
    </div>
  </section>

  <section class="benefits">
    <div class="container">
      <div class="row text-center justify-content-center">
        <div class="col-lg-6 ">
          <h2 class="wow bounceInUp mt-5 pt-3">NOTE KAR<span> LO BENEFITS</span></h2>
        </div>
      </div>
      <div class="row mt-5">
        <div class="bhopu-lace-stripe">
          <img src="./images/benefits/bhopu.png" class="bhopu wow fadeIn">
          <img src="./images/benefits/lace-1.png" class="lace-1 wow flash" alt="">
        </div>
        <div class="col-lg-4 col-md-6 col-xl-4 col-xs-12">
          <div class="card">
            <div class="card-body">
              <div class="card-image text-center">
                <img class="wow fadeInUp" src="./images/benefits/rocket.png" alt="">
              </div>
              <p class="card-text wow fadeInUp">Skyrocket Your Brand's Visibility: Memes = Sixes of Exposure!</p>
            </div>
            <div class="bottom-stripe">
              <img src="./images/benefits/pink-stripe.png" alt="" class="pink-bottom-stripe">
            </div>
          </div>

        </div>
        <div class="col-lg-4 col-md-6 col-xl-4 col-xs-12">
          <div class="card purple">
            <div class="card-body">

              <div class="card-image text-center">
                <img class="wow fadeInUp" src="./images/benefits/pie-chart.png" alt="">
              </div>
              <p class="card-text wow fadeInUp">More Shares Than a Cricket Ball in an ODI Match</p>
            </div>
            <div class="bottom-stripe">
              <img src="./images/benefits/pink-stripe.png" alt="" class="pink-bottom-stripe">
            </div>
          </div>

        </div>
        <div class="col-lg-4 col-md-6 col-xl-4 col-xs-12">
          <div class="card">
            <div class="card-body">

              <div class="card-image text-center">
                <img class="wow fadeInUp" src="./images/benefits/link.png" alt="">
              </div>
              <p class="card-text wow fadeInUp">Connect with Fans Like
 a Last-Ball Yorker – Perfect
 and Impactful!
</p>
            </div>
            <div class="bottom-stripe">
              <img src="./images/benefits/pink-stripe.png" alt="" class="pink-bottom-stripe">
            </div>
          </div>

        </div>
        <div class="col-lg-4  col-md-6 col-xl-4 col-xs-12">
          <div class="card purple">
            <div class="card-body">

              <div class="card-image text-center">
                <img class="wow fadeInUp" width="65" src="./images/benefits/online-learning.png" alt="">
              </div>
              <p class="card-text wow fadeInUp">Online Presence Bigger 
than a Stadium Roar

              </p>
            </div>
            <div class="bottom-stripe">
              <img src="./images/benefits/pink-stripe.png" alt="" class="pink-bottom-stripe">
            </div>
          </div>

        </div>
        <div class="col-lg-4 col-md-6 col-xl-4 col-xs-12">
          <div class="card">
            <div class="card-body">

              <div class="card-image text-center">
                <img class="wow fadeInUp" width="45" src="./images/benefits/meme.png" alt="">
              </div>
              <p class="card-text wow fadeInUp"> Unleash the Meme
 Beast, Be Unforgettable!
</p>
            </div>
            <div class="bottom-stripe">
              <img src="./images/benefits/pink-stripe.png" alt="" class="pink-bottom-stripe">
            </div>
          </div>

        </div>
        <div class="col-lg-4 col-md-6 col-xl-4 col-xs-12">
          <div class="card purple">
            <div class="card-body">

              <div class="card-image text-center">
                <img class="wow fadeInUp" src="./images/benefits/eye.png" alt="">
              </div>
              <p class="card-text wow fadeInUp"> Hit Bulls-Eye Demographics with Meme Magic</p>
            </div>
            <div class="bottom-stripe">
              <img src="./images/benefits/pink-stripe.png" alt="" class="pink-bottom-stripe">
            </div>
          </div>

        </div>
        <div class="bhopu-lace-issi">
          <img src="./images/benefits/bhangra.png" class="bhangra" alt="">
        </div>

      </div>
  </section>

  <section class="our_clients">
    <div class="container">
      <div class="row">
        <div class="col-lg-12  text-center">
          <h2 class="wow bounceInUp mb-3 ">HALL<span> OF FAME</span></h2>
          <h6 class="wow fadeInUp"> Our meme magic worked for them. It will work for you too!<span class="font-weight-bold span"> </span> 
          </h6>
        </div>
      </div>
      <div class="Logos_Row clearfix mt-5">
        <div class="Logo_IMG">
          <img src="images/clients/logo-14.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-02.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-03.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-17.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-16.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-12.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-07.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-15.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-06.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-01.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-04.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-05.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-13.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-18.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-08.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-10.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-09.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-11.png" />
        </div>

        <!-- new -->
        <div class="Logo_IMG">
          <img src="images/clients/logo-19.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-20.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-21.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-22.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-23.png" />
        </div>
        <div class="Logo_IMG">
          <img src="images/clients/logo-24.png" />
        </div>


      </div>
    </div>
  </section>


  <section id="Problem">
    <div class="container">
      <div class="row problem-outer align-items-center">
        <div class="problem-inner-left col-lg-6 col-md-6 col-12">
          <!-- <p class="Haslo-sab">Haslo sab</p> -->
          <img class="wow zoominUp" src="./images/problem/Layer 17.png" alt="" class="massage">
        </div>
        <div class="problem-inner-right col-lg-6 col-md-6 col-12">
          <div class="Yawn-Worthy_bbox">
                <div class="CWC_box">
                    <h2 class="wow fadeInUp">Sick of Yawn-Worthy </h2>
                    <p class="wow fadeInUp">Marketing During Cricket <br/> World Cup Fever?</p>
                </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- backgroundbg-cricket section start here..  -->
  <section id="backgroundbgcricket">
    <h2 class="wow fadeInUp">Presenting Mememarketing<br>
      Play your best social media innings<br>
       <span> During this cricket World Cup</span> </h2>



    <div class="outer-background-cricket">
      <img src="./images/bothcricket.png" alt="">
    </div>

    <div class="container">
        <div class="backgroundcricket-card">
          <div class="background-inner-card col-lg-3 col-md-6 col-12">
            <img class="wow fadeInUp" width="40" src="./images/backgroungphonesmile.png" alt="">
            <p class="wow fadeInUp">Tailored Memes that Break the Internet Faster than a Hat-Trick</p>
          </div>
          <div class="background-inner-card col-lg-3 col-md-6 col-12">
            <img class="wow fadeInUp" width="50" src="./images/backgroundmen.png" alt="">
            <p class="wow fadeInUp">Data + Memes = Our Superpower for Jaw- Dropping Impact</p>
          </div>
          <div class="background-inner-card col-lg-3 col-md-6 col-12">
            <img class="wow fadeInUp" width="55" src="./images/backgroundsmile.png" alt="">
            <p class="wow fadeInUp">Expert Memers Crafting Virality Beyond Boundaries</p>
          </div>
          <div class="background-inner-card col-lg-3 col-md-6 col-12">
            <img class="wow fadeInUp" width="55" src="./images/backgroundcard.png" alt="">
            <p class="wow fadeInUp">Meme Bowling at the Right Times for Maximum Roars</p>
          </div>
        </div>
    </div>
  </section>
  <!-- backgroundbg-cricket section End here..  -->




  <!-- <section class="problems">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-12">
           <div class="left-hand">
            <div class="cloud">
              <img src="./images/problem/cloud.png" alt="">
              <h6>haslo sab</h6>
            </div>
            <div class="ganja">
              <img src="./images/problem/ganja.png" alt="">
            </div>
           </div>
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          <div class="right-hand">
            <img src="./images/problem/up-smiley.png" class="ups" alt="">
            <h2>Problem & <span style="color: yellow;"> Agitation</span> </h2>
            <h6>Sick of Yawn-Worthy <span class="font-weight-bold">Marketing 
              During Cricket World Cup Fever?</span> 
              </h6>
            <img src="./images/problem/down-smiley.png" class="downs" alt="">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-12">
          <img src="./images/problem/bottom-stripe.png" alt="" class="problem-stripe">
        </div>

      </div>
    </div>
  </section> -->

  <!-- Credibility  section start here.. -->

  <section id="Credibility">
    <div class="container">
      <!--<div class="row">-->
      <!--  <h2 class="cred">Credibility</h2>-->
      <!--</div>-->
      <div class="row outer-credibility">
      <div class="inner-credivility-left orange col-lg-4 col-md-4 col-12">
          <img src="" class="Thunderright" alt="" />
          <h2 class="wow fadeInUp">MAIN NAHI TOH <span>KAUN BEY</span></h2>
          <p class="mb-0">&nbsp;</p>
          <div class="color-skyblue cx cx2">
            <img src="./images/shrusty.png" alt="" />
          </div>
          <!-- <img src="./images/Thunderleft.png" class="Thunderleft" alt="" /> -->
        </div>
        <div class="inner-credivility-left col-lg-4 col-md-4 col-12">
          <img src="" class="Thunderright" alt="" />
          <h2 class="wow fadeInUp">OUR <span>SCORECARD</span></h2>
          <p class="wow fadeInUp">200+ Epic Campaigns that have Ruled the Social Media Space</p>
          <div class="color-skyblue cx">
            <img src="./images/Thundersuperman.png" alt="" />
          </div>
          <!-- <img src="./images/Thunderleft.png" class="Thunderleft" alt="" /> -->
        </div>
        <div class="inner-credivility-right col-lg-4 col-md-4 col-12">
          <img src="" class="Thunderup" alt="" />
          <h2 class="wow fadeInUp"> Pro Meme <span>Squad</span></h2>
          <p class="wow fadeInUp"> Our Memesters Know Meme-ology Like the Back of Their Hands!</p>
          <div class="color-skyblue cx1">
            <img src="./images/Thundergirl.png" alt="" />
          </div>
          <!-- <img src="./images/Thunderdown.png" class="Thunderdown" alt="" /> -->
        </div>
      </div>
    </div>


  </section>
  <!-- Credibility section End here.. -->




  <!-- price coin srection start here . -->
  <section id="price-coin">
    <div class="container poisition-relative">
      <div class="row price-coin-outer">
        <div class="price-coin-inner-left col-lg-6 col-md-6 col-12">
            <div class="overflow_img">
                <img src="./images/akshay.png" class="coin-men" alt="" />
            </div>
          <!-- <img src="./images/coin-men.png" class="coin-men" alt="" /> -->
          <img src="./images/coin-left.png" class="coin-left" alt="" />
        </div>
        <div class="price-coin-inner-right col-lg-6 col-md-6 col-12">
          <img src="./images/coinright.png" class="coinright" alt="" />
          <h2 class="wow fadeInUp">NAHI AAYA?</h2>
          <!-- <p>Deals as Good as a Maiden Over</p> -->
          <button class="akki-btn"><a data-toggle="modal" data-target="#formmodal">Aaoo Samjhate Hain</a></button>
        </div>
      </div>
      <div class="row circle-dots">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
      </div>
    </div>
  </section>
  <!-- price coin srection End here . -->



  <!-- sticky-note section start here. -->
  <section id="sticky-note">
    <div class="container">
      <div class="row">
        <div class="sticky-note-outterr col-lg-12 col-md-12 col-12">
          <h2 class="faq wow fadeInUp">FAQs</h2>
        </div>
        <div class="sticky-note-outterr ">
          <div class="sticky-outer c123">
            <div class="sticky-inner-1 col-lg-4 col-md-6 col-12">
              <h2 class="wow fadeInUp">Can memes really win the Cricket World Cup for my brand?</h2>
              <p class="wow fadeInUp">
                Absolutely! Memes hit harder than a Yorker, connecting with fans
                across the crease.
              </p>
            </div>

            <div class="sticky-inner-2 col-lg-4 col-md-6 col-12">
              <h2 class="wow fadeInUp">Can you meme in our brand's voice ?</h2>
              <p class="wow fadeInUp">
                For Sure! We've got a Memesmith who knows cricket, pop culture,
                and your brand like Dhoni knows his stumpings.
              </p>
            </div>
          </div>
          <div class="sticky-outer c321">
            <div class="sticky-inner-1 sticky-inner-3 col-lg-4 col-md-6 col-12">
              <h2 class="wow fadeInUp">Will I know how my memes are performing?</h2>
              <p class="wow fadeInUp">
                Hell yeah! We've got stats that'll make even a cricket analyst grin.
              </p>
            </div>
            <div class="sticky-inner-2 sticky-inner-4 col-lg-4 col-md-6 col-12">
              <h3 class="font-style">Or kuch puchna haikey</h3>
              <!-- <p>For Sure! We've got a Memesmith who knows cricket, pop culture, and your brand like Dhoni knows his stumpings.</p> -->
            </div>
          </div>
        </div>
        <div class="sticky-note-outterr col-lg-12 col-md-12 col-12">
          <div class="get-a-quick-quote">
            <button class="note"><a data-toggle="modal" data-target="#formmodal">Get a Quick Quote!</a></button>
          </div>
        </div>
      </div>
    </div>
    </div>

  </section>

  <!-- smile-card section start here..  -->
  <section id="smile">
    <div class="container">
      <div class="row">
        <div class="outer-smile">
          <div class="left-smile col-lg-6 col-md-6 col-12">
            <img src="./images/smilehappiness.png" alt="" />
            <h2 class="wow fadeInUp">
              Ready to Smash Memes for Six? Let's Get Your MemeSlam Squad in
              Action
            </h2>
          </div>
          <div class="right-smile col-lg-6 col-md-6 col-12">
            <img src="./images/smilecricket.png" alt="" />
            <h2 class="wow fadeInUp">Score Big with Memes this Cricket World Cup! Let's Play!</h2>
          </div>
        </div>
      </div>
    </div>

  </section>
  <!-- smile-card section End here..  -->



  <footer class="wow fadeInUp">
    <div class="container">
      <div class="row footer-outer">
        <div class="col-lg-5 col-md-5 col-12 footer-inner-left">
          <div style="margin: 0px 40px 0px;">
            <h2 class="wow fadeInUp">Contact Address</h2>
            <p class="wow fadeInUp">D-111, Floor No. 1, Sector 63, Noida, India</p>

            <h2 class="wow fadeInUp">Contact Number</h2>
            <p class="wow fadeInUp"><a href="+91 9599565161">+91 9599565161</a></p>

            <h2 class="wow fadeInUp">Email Address</h2>
            <p class="wow fadeInUp"><a href="mailto:xoxo@mememarketing.in">xoxo@mememarketing.in</a></p>

            <a target="_lank" href="https://www.facebook.com/mememarketingxoxo"><i class="fa-brands fa-facebook-f footer-icon" style="color: #ffffff"></i></a>
            <a target="_lank" href="https://www.instagram.com/mememarketingxoxo/"><i class="fa-brands fa-instagram footer-icon" style="color: #ffffff"></i></a>
            <a target="_lank" href="https://www.linkedin.com/showcase/xoxo-meme-marketing/"><i class="fa-brands fa-linkedin-in footer-icon" style="color: #ffffff"></i></a>
          </div>

        </div>

        <div class="col-lg-3 col-md-3 col-12 footer-inner-centre">
            <h2 class="wow fadeInUp">LINKS</h2>
            <!--<p><a href="https://mememarketing.in/blogs.php" target="_blank">Blogs</a></p>-->
            <p><a data-toggle="modal" data-target="#formmodal">Contact Us</a></p>
        </div>

        <div class="col-lg-4 col-md-4 col-12 footer-inner-right">
          <div>
            <h2 class="wow fadeInUp">Newsletter</h2>
            <p>Get your newsletter here</p>

            <form action="">
              <input type="mailto:" placeholder="Email" value="Email" required />
              <input type="submit" value="Submit" />
            </form>
          </div>
        </div>

        <span class="footer-background-icon">
          <img src="./images/footer/footershape right.png" alt="" />
          <img src="./images/footer/footerEllipse .png" alt="" />
          <!-- <img src="./images/footer/footershapeleft.png" alt="" /> -->
        </span>
      </div>
    </div>
    <div class="copyright">
        <div class="container">
            <div class="col-lg-12 copyright-1">
              <p class="">© 2023 2023 MEME MARKETING</p>
            </div>
        </div>
    </div>
  </footer>

<div class="modal fade" id="formmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">You are just one step away.</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="mail.php" method="post" name="contact-form" class="contactf">
                    <div class="messages"></div>
                    <div class="form-group">
                        <label class="sr-only" for="name">Name</label>
                        <input type="text" name="name" class="form-control" id="name-3" required="required"
                            placeholder="Name*" data-error="Your Name is Required">
                        <div class="help-block with-errors mt-20"></div>
                    </div>
                    <div class="form-group">
                        <label class="sr-only" for="email">Email</label>
                        <input type="email" name="email" class="form-control" id="email-3" placeholder="Email Address*"
                            required="required" data-error="Please Enter Valid Email">
                        <div class="help-block with-errors mt-20"></div>
                    </div>
                    <div class="form-group">
                        <label class="sr-only" for="phone">Phone</label>
                        <input type="text" name="phone" class="form-control" id="phone" placeholder="Contact Number*"
                            required="required" pattern="[789][0-9]{9}" data-error="Please Enter Valid Phone Number">
                        <div class="help-block with-errors mt-20"></div>
                    </div>
                    <div class="form-group">
                        <label class="sr-only" for="company">Company</label>
                        <input type="text" name="company" class="form-control" id="company" placeholder="Company"
                            required="required" data-error="Please Enter Valid Company Name">
                        <div class="help-block with-errors mt-20"></div>
                    </div>
                    <div class="form-group">
                        <label class="sr-only" for="company">Designation</label>
                        <input type="text" name="designation" class="form-control" id="designation" placeholder="Designation"
                            required="required" data-error="Please Enter Valid Designation">
                        <div class="help-block with-errors mt-20"></div>
                    </div>
                    <div class="form-group">
                        <label class="sr-only" for="message">Message</label>
                        <textarea name="message" class="form-control" id="message-3" rows="7" placeholder=" Message"
                            required data-error="Please, Leave us a message"></textarea>
                        <div class="help-block with-errors mt-20"></div>
                    </div>
                   <!--  <input type="hidden" name="utm_term" value>
                    <input type="hidden" name="utm_source" value>
                    <input type="hidden" name="utm_medium" value>
                    <input type="hidden" name="utm_campaign" value>
                    <input type="hidden" name="last_url" value>
                    <input type="hidden" name="ip" value="2401:4900:1c62:c7b7:493b:f2c6:9be:9601">
                    <input type="hidden" name="device" value="desktop"> -->
                    <p class="text-center">
                        <button type="submit" name="submit" class="btn btn-color btn-circle">Send Request <i
                                class="mdi mdi-email"></i></button>
                    </p>
                </form>
            </div>
        </div>
    </div>
</div>
<a data-toggle="modal" data-target="#formmodal" class="callToaction">
  <img width="35" class="shakeAni" src="./images/email.png"></a>
</body>
<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script defer src="js/popper.min.js"></script>
<script defer src="js/bootstrap.min.js"></script>
<script defer src="js/wow.min.js"></script> 
<script defer src="js/script.js"></script>


</html>


  <!--BEGIN :: Section-->
<!-- <section class="section-wrapper"> -->
  
  <!-- BEGIN :: Floating Action Button -->
  <!-- <div class="floating-action-button"> -->
    
    <!-- BEGIN :: Floating Button -->
<!--     <div class="share-btn">
      <i id="share-icon" class="fa fa-share-alt" name="share-social"></i>
      <i id="close-icon" class="fa fa-plus" name="close-sharp"></i>
    </div> -->
    <!-- END :: Floating Button -->
    
    <!-- BEGIN :: Expand Section -->
<!--     <ul>
      <li>
        <a <i class="fa fa-twitter" name="logo-twitter"></i>
      </li>
      <li>
        <a target="_lank" href="https://www.facebook.com/mememarketingxoxo"><i class="fa fa-facebook" name="logo-facebook"></i></a>
      </li>
      <li>
        <i class="fa fa-whatsapp" name="logo-whatsapp"></i>
      </li>
      <li>
        <a target="_lank" href="https://www.linkedin.com/showcase/xoxo-meme-marketing/"><i class="fa fa-linkedin" name="send-linkedin"></i></a>
      </li>
      <li>
       <a target="_lank" href="https://www.instagram.com/mememarketingxoxo/"> <i class="fa fa-instagram" name="logo-instagram"></i></a>
      </li>
    </ul> -->
    <!-- END :: Expand Section -->
    
  <!-- </div> -->
  <!-- END :: Floating Action Button -->
  
  
  
<!-- </section> -->
<!--END :: Section -->