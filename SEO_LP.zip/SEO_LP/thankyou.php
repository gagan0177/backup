<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Digipanda Consulting Pvt. Ltd.">
    <meta name="generator" content="">
    <title>Digipanda Consulting Pvt. Ltd.</title>
    <link rel="shortcut icon" type="x-icon" href="images/fav.png">
    <!-- Bootstrap core css -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/animate.css" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/css/intlTelInput.css'>
    <link rel="stylesheet" href="css/responsive.css">
    <script src="https://kit.fontawesome.com/9ec80a7684.js" crossorigin="anonymous"></script>
    <style>
    /* .thnk {
        background: url('https://digipanda.co.in/elite-program/assets/images/slides/home-bg-6.jpg');
    } */
    nav.thankyou{
        display:flex;
        justify-content:center!important;
    }
    .thnkyou-cont {
        margin-top: 100px;
    }

    .thnkyou-cont h1 {
        text-align: center;
        font-size: 54px;
        letter-spacing: 0;
        line-height: 70px;
        padding-bottom: 30px;
    }
    .thnkyou-cont h3{
        margin-bottom: 100px;
    }
    </style>
</head>


<body>

    <section id="header" class="wow fadeInUp">
        <div class="container">
            <div class="row">
                <nav class="thankyou">
                    <div class="logo"><img width="190" src="images/Green.png" alt=""></div>
                    
                </nav>
            </div>
        </div>
    </section>

    <section id="banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="thnkyou-cont">
                        <h1 class="white-color font-700 letter-spacing-5" style="color:#fff;">Thank you for enquiry.
                        </h1>
                        <h3 class="text-center mt-30 digi1" style="color:#fff;">We will contact you soon. </h3>


                    </div>
                </div>

            </div>
        </div>
    </section>



    <footer>
        <div class="container">
            <div class="footer-outer">
                <div class="footer-inner">
                    <div class="link">
                        <a href="https://www.facebook.com/DigiPandaconsulting/" target="_blank"> <i
                                class="fa-brands fa fa-facebook"></i></a>
                        <a href="https://www.linkedin.com/company/digipanda-consulting" target="_blank"><i
                                class="fa-brands fa fa-linkedin"></i></a>
                        <a href="https://twitter.com/digipanda_IN" target="_blank"><i
                                class="fa-brands fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/digipanda_in/" target="_blank"><i
                                class="fa-brands fa fa-instagram"></i></a>
                    </div>
                </div>
                <div class="footer-inner">
                    <p>© 2023 All Rights Reserved. <a href="#">digiPaᴎda Consulting Pvt. Ltd.</a></p>
                </div>

            </div>
        </div>
    </footer>

</body>



<script src="js/jquery-3.5.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src='js/intlTelInput-jquery.min.js'></script>
<script type="text/javascript">
// -----Country Code Selection
$("#mobile_code1, #mobile_code2, #mobile_code3").intlTelInput({
    initialCountry: "in",
    separateDialCode: true,
    hiddenInput: "phone",
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.4/js/utils.js"
});
</script>
<script defer src="js/wow.min.js"></script>
<script defer src="js/script.js"></script>

</html>