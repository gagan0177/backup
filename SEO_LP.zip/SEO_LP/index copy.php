<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Digipanda Consulting Pvt. Ltd.">
    <meta name="generator" content="">
    <title>Digipanda Consulting Pvt. Ltd.</title>
    <link rel="shortcut icon" type="x-icon" href="images/fav.png">
    <!-- Bootstrap core css -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/animate.css" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/css/intlTelInput.css'>
    <link rel="stylesheet" href="css/responsive.css">
    <script src="https://kit.fontawesome.com/9ec80a7684.js" crossorigin="anonymous"></script>
</head>

<body>

<!-- The Modal -->
<div class="modal fade" id="myModalform">
        <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header border-0 pb-0">
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body pt-0">
            <div class="register-form-wrapper p-4 mt-0">
                <h3 class="mb-4">Fill the details below & let us contact you.</h3>
                <div>
                    <p class="register_success_box" style="display:none;">We received your message and you will hear from us soon. Thank You!</p>
                      <form id="register-form" class="register-form register"  method="post">
                        <input class="register-input name-input white-input" required="" name="name" placeholder="Your Name*" type="text">
                        <input class="register-input name-email white-input" required="" name="email" placeholder="Email Address*" type="email">
                        <input class="register-input name-phone white-input" required="" id="mobile_code3" name="phone" placeholder="Phone Number*" type="text">
                        <textarea placeholder="Your Query" name="msg"  required="" class="register-input name-message white-input mt-3"></textarea>
                        <input value="Submit" class="register-submit mt-4" name="submit" type="submit">
                    </form>
                </div>
            </div>
        </div>
      </div>
        </div>
    </div>

  <section id="header" class="wow fadeInUp">
    <div class="container">
      <div class="row">
        <nav>
          <div class="logo"><img width="190" src="images/Green.png" alt=""></div>
          <div class="top-contact ">
              <div class="phone-no">
                  <img class="shakeAni" src="images/phone-call.png" alt=""><a href="tel:8448 835 766">8448 835 766</a>
              </div>
      
              <div class="top-message">
                <a data-bs-toggle="modal" data-bs-target="#myModalform" class="wobble-horizontal">  <img src="images/Layer 47.png" alt=""><span>Enquire Now</span></a>
              </div>
          </div>
      </nav>
      </div>
    </div>
  </section>

  <section id="banner">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-12">
          <div class="left-hand-side">
             <p class="result wow fadeInUp">No <span class="green-digi fw-bold">Result</span>, <span class="fw-bold" style="color: #f86019;">No</span> Payment</p>
             <p class="aim wow fadeInUp">Our agency stands by its commitment to deliver tangible success.</p>
             <p class="book mt-3 wow fadeInUp" style="color: #f86019;"><span class="fw-bold">29 Slots</span> left for this month</p>
             <button class="pay-btn mt-3 wobble-horizontal">Check your Eligibility <span>&#8594;</span></button>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          <div class="right-hand-side">
             <p class="case-study wow fadeInUp"><u>View Case Studies</u></p>


             <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
              <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
              </div>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <div class="data-img">
                    <img src="images/data.png" alt="">
                  </div>
                </div>
                <div class="carousel-item">
                  <div class="data-img">
                    <img src="images/data1.png" alt="">
                  </div>
                </div>
                <div class="carousel-item">
                  <div class="data-img">
                    <img src="images/data2.png" alt="">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="reviews" class="wow fadeIn">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-12">
          <div class="left-area">
            <div class="left-review">
              <p class="review wow fadeInUp"><b>That's right, ladies and gentlemen,</b> we're putting our money where our mouth is! With a decade-long track record of success, we're introducing a unique approach. Try our services on a trial basis, with payment only <b>upon achieving your predefined goals. Zero risk, infinite possibilities</b> </p>
            </div>
            <div class="google-imgs">
              <img src="images/reviews/awa.png" alt="">
              <img src="images/reviews/googler.png" alt="" class="googler" >
              <img src="images/reviews/revi.png" alt="" >
            </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-12">
          <div class="right-area">
            <div class="right-imgs">
              <img src="images/reviews/Layer 19.png" alt="" class="d-block green-stars">
              <img src="images/reviews/Layer 20.png" alt="" class="rope-design">
            </div>
            <div class="right-content">
              <p>that's the <span class="green-digi fw-bold">commitment</span> we stand by!</p>
              <div class="rocket-img text-center">
                <img src="images/reviews/Layer 21.png" alt="">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="top-features">
     <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6 col-12">
          <div class="top-feature-card">
            <div class="top-feature-img">
              <img class="wow fadeInUp" src="images/top-feature/back-in-time.png" alt="">
            </div>
            <div class="top-features-detail">
              <p class="green-digi wow fadeInUp">Limited Availiabilty</p>
            </div>
          </div>
          
        </div>
        <div class="col-lg-3 col-md-6 col-12">
          <div class="top-feature-card">
            <div class="top-feature-img">
              <img class="wow fadeInUp" src="images/top-feature/free.png" alt="">
            </div>
            <div class="top-features-detail">
              <p class="wow fadeInUp">Free <br/> Program</p>
            </div>
          </div>
          
        </div>
        <div class="col-lg-3 col-md-6 col-12">
          <div class="top-feature-card">
            <div class="top-feature-img">
              <img class="wow fadeInUp" src="images/top-feature/earning.png" alt="">
            </div>
            <div class="top-features-detail">
              <p class="green-digi wow fadeInUp">Proven Startgies</p>
            </div>
          </div>
          
        </div>
        <div class="col-lg-3 col-md-6 col-12">
          <div class="top-feature-card">
            <div class="top-feature-img">
              <img class="wow fadeInUp" src="images/top-feature/darts.png" alt="">
            </div>
            <div class="top-features-detail">
              <p class="wow fadeInUp">Result Oriented</p>
            </div>
          </div>
          
        </div>
      </div>
     </div>
  </section>


   <section id="promise" class="wow fadeIn">
    <div class="container">
      <div class="row">
          <div class="No-Fake-Promise">
            <div class="No-Fake-Promise-inner col-lg-6 col-md-6 col-12 order2">
                <div class="clicle-blank">
                    <img src="images/promise/chart.png" alt="">
                    <p class="wow fadeInUp"> SEO Elite Program</p>
                </div>
            </div>
            <div class="No-Fake-Promise-inner col-lg-6 col-md-6 col-12">
              <div class="seoElite-blank">
                <h2 class="wow fadeInUp">No <span>Fake<br> Promise </span> </h2>
                <p class="elite-content">with our SEO Elite Program</p>
                <!-- <button><a href="#">Check your Eligibiity </a><i class="fa-solid fa-arrow-right-long" -->
                  <!-- style="color: #809ed0;"></i></button> -->
                  <button class="pay-btn wobble-horizontal">Check your Eligibility <span>&#8594;</span></button>
              </div>
            </div>
          </div>
      </div>
    </div>
  </section> 

  <section id="video">
    <div class="container">
      <div class="row">
        <div class="col-lg-10 offset-lg-1 vid-img text-center">
          <!-- <img class="wow fadeIn" src="images/elite.png" alt="" class="elite"> -->
          <div class="vidbg-container">
            <video playsinline="" autoplay="" loop="" muted="">
              <source src="images/Web3.mp4" type="video/mp4">
            </video>
            <!-- <div class="SEO_Search">
              <img src="images/SEO_Search.png" />
            </div> -->
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="digi4">
    <div class="container">
      <div class="row row-1">
        <div class="col-12 col-md-12 col-lg-4 feature-box">
          <div class="feature-cards">
            <div class="feature-number">
              <p>01</p>
            </div>
            <div class="features">
              <div class="feature-icon green-bg-icon circle-icon text-center">
                <img class="wow fadeInUp" src="images/features/network.png" alt="" />
              </div>
              <div class="feature-head">
                <p><span class="fw-bold">Organic</span> Tranformation</p>
              </div>
              <div class="feature-desc">
                <p>
                  Discover your website's organic ransformation, unlocking new
                  levels of engagement and conversions.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-12 col-lg-4 feature-box">
          <div class="feature-cards">
            <div class="feature-number">
              <p>02</p>
            </div>
            <div class="features">
              <div class="feature-icon green-bg-icon circle-icon text-center">
                <img class="wow fadeInUp" src="images/features/network.png" alt="" />
              </div>
              <div class="feature-head">
                <p><span class="fw-bold">5X Your</span> Revinuew</p>
              </div>
              <div class="feature-desc">
                <p>
                  Discover your website's organic ransformation, unlocking new
                  levels of engagement and conversions.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-12 col-lg-4 feature-box">
          <div class="feature-cards">
            <div class="feature-number">
              <p>03</p>
            </div>
            <div class="features">
              <div class="feature-icon green-bg-icon circle-icon text-center">
                <img class="wow fadeInUp" src="images/features/network.png" alt="" />
              </div>
              <div class="feature-head">
                <p><span class="fw-bold">Brandify</span></p>
              </div>
              <div class="feature-desc">
                <p>
                  Discover your website's organic ransformation, unlocking new
                  levels of engagement and conversions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row row-2">
        <div class="col-12 section-heading">
          <p class="wow fadeTop">
            Lorem publishing and graphic design, Lorem ipsum is a placeholder
            text commonly
          </p>
          <img src="images/features/Layer 29.png" alt="" />
        </div>
        <div class="row row-3">
          <div class="col-12 col-md-6 col-lg-3 text-center">
            <div class="emoji-cards">
              <div class="emoji-pic">
                <img class="wow fadeInUp" src="images/features/thumb.png" alt="" />
              </div>
              <div class="emoji-content">
                <div class="emoji-number">
                  <p>8766</p>
                </div>
                <div class="emoji-head">
                  <p>Client Meeting</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-3 text-center">
            <div class="emoji-cards">
              <div class="emoji-pic">
                <img class="wow fadeInUp" src="images/features/smiley.png" alt="" />
              </div>
              <div class="emoji-content">
                <div class="emoji-number">
                  <p>800+</p>
                </div>
                <div class="emoji-head">
                  <p>Happy Clients</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-3 text-center">
            <div class="emoji-cards">
              <div class="emoji-pic">
                <img class="wow fadeInUp" src="images/features/cup.png" alt="" />
              </div>
              <div class="emoji-content">
                <div class="emoji-number">
                  <p>9376</p>
                </div>
                <div class="emoji-head">
                  <p>Cups of Coffee</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-3 text-center">
            <div class="emoji-cards">
              <div class="emoji-pic">
                <img class="wow fadeInUp" src="images/features/deliver.png" alt="" />
              </div>
              <div class="emoji-content">
                <div class="emoji-number">
                  <p>1200+</p>
                </div>
                <div class="emoji-head">
                  <p>Project Deliver</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="pay">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-12 left-hand-pay">
          <div class="pay-content">
            <p class="wow fadeInUp">
              <span class="fw-bold"> Pay only</span> when your
              <span class="green-digi">goals</span><span class="fw-bold"> are achive</span>
            </p>
          </div>
          <div class="btn-images wow fadeInUp">
            <button class="pay-btn wobble-horizontal">Act Quickly <span>&#8594;</span></button>
            <img src="images/pay/Layer 29.png" class="design" alt="" />
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-12 right-hand-cash">
          <img src="images/pay/hand.png" alt="" class="hand wow fadeIn" />
        </div>
      </div>
    </div>
  </section>

  <section class="confident">
    <div class="container-fluid">
      <div class="row">
        <div class="Why-are-we-so">
          <div class="Why-are-we-so-outer">
            <div class="Why-are-we-so-inner">
              <p class="head wow fadeInUp"><b>Why are</b> we so <b>confident</b></p>
              <div class="img">
                <img src="images/last/globe.png" alt="" class="globe">
                <img src="images/last/Layer 36.png" alt="" class="desktop">
              </div>
             
            </div>
            
        </div>
        <div class="last-childd">
          <p class="wow fadeInUp">Hie Website Visitor Increase<b>d</b> <span class="green-digi">305% in 2 months</span></p> 
        </div>
      </div>
    </div>
  </section>

  <section id="last-part">
    <div class="container">
      
      <div class="row logos">
        <p class="text-center mb-3 wow fadeInUp">Trusted by top company</p>
        <!-- <img src="images/logos.png" alt=""> -->
        <div class="logo-container">
          <div class="col-lg-2 col-md-4 col-6 logo_img">
            <img src="images/logos/sirona.png" alt="">
          </div>
          <div class="col-lg-2 col-md-4 col-6 logo_img">
            <img src="images/logos/rekoop.png" alt="">
          </div>
          <div class="col-lg-2 col-md-4 col-6 logo_img">
            <img src="images/logos/pan vilas.png" alt="">
          </div>
          <div class="col-lg-2 col-md-4 col-6 logo_img">
            <img src="images/logos/zones.png" alt="">
          </div>
          <div class="col-lg-2 col-md-4 col-6 logo_img">
            <img src="images/logos/think.png" alt="">
          </div>
          <div class="col-lg-2 col-md-4 col-6 logo_img">
            <img src="images/logos/ascension.png" alt="">
          </div>
        </div>
      </div>
      <div class="row mt-5 align-items-center">
        <div class="col-lg-6 col-12 man">
          <img src="images/worried.png" alt="">
        </div>
        <div class="col-lg-6 col-12 content">
          <h5 class="wow fadeInUp">Still <span class="fw-bold">Worried?</span></h5>
          <p class="small-desc wow fadeInUp">Say Goodbye to Wasted Budgets, Say Hello to Maximum ROI !</p>
          <p class="last-desc mt-3 wow fadeInUp">No more throwing money at half-baked campaigns or unqualified leads. Our Elite
            Program is engineered to deliver the highest return on your investment, guaranteed! Watch your profits
            skyrocket as we optimize every penny spent, leaving your competition in the dust.</p>
          <button class="pay-btn wobble-horizontal">Check your Eligibility <span>&#8594;</span></button>
        </div>
      </div>
    </div>
  </section>

  <footer>
   <div class="container">
    <div class="footer-outer">
        <div class="footer-inner">
            <div class="link">
               <a href="https://www.facebook.com/DigiPandaconsulting/" target="_blank"> <i class="fa-brands fa fa-facebook" ></i></a>
               <a href="https://www.linkedin.com/company/digipanda-consulting" target="_blank"><i class="fa-brands fa fa-linkedin" ></i></a>
               <a href="https://twitter.com/digipanda_IN" target="_blank"><i class="fa-brands fa fa-twitter" ></i></a>
               <a href="https://www.instagram.com/digipanda_in/" target="_blank"><i class="fa-brands fa fa-instagram" ></i></a>
            </div>
        </div>
        <div class="footer-inner">
            <p>© 2023 All Rights Reserved. <a href="#">digiPaᴎda Consulting Pvt. Ltd.</a></p>
        </div>

    </div>
   </div>
  </footer>

</body>



<script src="js/jquery-3.5.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src='js/intlTelInput-jquery.min.js'></script>
  <script type="text/javascript">
  // -----Country Code Selection
      $("#mobile_code1, #mobile_code2, #mobile_code3").intlTelInput({
          initialCountry: "in",
          separateDialCode: true,
          hiddenInput: "phone",
          utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.4/js/utils.js"
      });
  </script>
<script defer src="js/wow.min.js"></script>
<script defer src="js/script.js"></script>

</html>