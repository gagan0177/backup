<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="">
    <meta name="author" content="TebTest">
    <meta name="generator" content="">
    <title>TebTest</title>
    <link rel="shortcut icon" type="x-icon" href="img/fav.png">
    <!-- Bootstrap core css -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap core css -->
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/flaticon.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">

    <!-- Custom styles for this site -->
    <link href="css/main-web.css" rel="stylesheet">
    <link href="css/responsive-web.css" rel="stylesheet">
</head>

<body>

    <?php include 'header.php';?>

    <section class="banner wow fadeIn">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12  col-xl-6">
                    <div class="banner-content position-relative">
                        <h1 class="wow fadeInUp"><span class="think">Think</span> <span class="online">Online
                                Examination! </span> <br/><span class="think">Think</span><span class="online">
                                TABTEST</span> </h1>
                        <p class="wow fadeInUp mt-4">End-to-end cloud-based online exam software that enables you to create,
                            configure, and report online exams.</p>
                        <img class="tilt" src="./img/arrow.png" alt="">
                        <a href="#" class="help_button banner-btn mt-4 wow fadeInUp">Book a Demo <span class="arow_btn">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor"
                                    class="bi bi-arrow-right" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd"
                                        d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z">
                                    </path>
                                </svg>
                            </span>


                        </a>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <section class="padding  text-center advantages">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="wow fadeInUp">Advantages</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12 p-0">
                            <div class="AdvantagesContent">
                                <div class="Advantages-icon wow fadeInUp">
                                    <img src="img/advan1.png" alt="" />
                                </div>
                                <h3 class="wow fadeInUp">Saving valuable time for teachers since no time is spent on grading tests</h3>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12 p-0">
                            <div class="AdvantagesContent">
                                <div class="Advantages-icon wow fadeInUp">
                                    <img src="img/advan2.png" alt="" />
                                </div>
                                <h3 class="wow fadeInUp">The capacity to test many students quickly</h3>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12 p-0">
                            <div class="AdvantagesContent border-0">
                                <div class="Advantages-icon wow fadeInUp">
                                    <img src="img/advan3.png" alt="" />
                                </div>
                                <h3 class="wow fadeInUp">Less money spent on administration and scoring</h3>
                            </div>
                        </div>
                        <!-- <div class="col-lg-4 col-md-6 col-sm-6 col-6 p-0">
                            <div class="AdvantagesContent">
                                <div class="Advantages-icon">
                                    <img src="img/assessment.png" alt="" />
                                </div>
                                <h3>A shortened assessment time due to adaptive testing</h3>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-6 p-0">
                            <div class="AdvantagesContent">
                                <div class="Advantages-icon">
                                    <img src="img/Interpretative.png" alt="" />
                                </div>
                                <h3>Interpretative algorithms that can inform teachers on effective interventions</h3>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-6 p-0">
                            <div class="AdvantagesContent border-0">
                                <div class="Advantages-icon">
                                    <img src="img/Opportunities.png" alt="" />
                                </div>
                                <h3>Opportunities to measure performance on time sensitive tasks</h3>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-6 p-0">
                            <div class="AdvantagesContent">
                                <div class="Advantages-icon">
                                    <img src="img/Increased.png" alt="" />
                                </div>
                                <h3>Increased ease of assessment in different languages</h3>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-6 p-0">
                            <div class="AdvantagesContent">
                                <div class="Advantages-icon">
                                    <img src="img/Automated.png" alt="" />
                                </div>
                                <h3>Automated data for research purposes</h3>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12 p-0">
                            <div class="AdvantagesContent border-0">
                                <div class="Advantages-icon">
                                    <img src="img/guarantee.png" alt="" />
                                </div>
                                <h3>While these features do not guarantee the exam integrity, it drastically reduces the
                                    opportunity for students to cheat electronically. </h3>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="bg-girl-section">
        <div class="container">
            <div class="row"></div>
        </div>
    </section>
    <section class="padding txt-center tabletInfo">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-5 text-center">
                    <img class="wow zoomIn" width="400" src="img/mobile-bg.png" alt="Introduction">

                </div>
                <div class="col-md-6 position-relative">
                   <h2 class="wow fadeInUp">WHY <span class="fw-bold" style="color:#bf1e2e;" >TABTEST</span></h2>
                    <div class="scrollbar mt-4" id="style-2">
                        <div class="force-overflow">
                            <p class="wow fadeInUp">The technology of today gives opportunity to completely new
                                ways of developing examination systems for both examiner and students. Our TabTest
                                solution is fully customizable to suit our client need. We have a highly secured
                                platform for conducting Examinations.This solution is feasible for Entrance Exams,
                                Recruitment Exams, Mock test, Semester Exam etc. We provide End-to-End solution</p>
                            <p class="wow fadeInUp mt-3">Through our Tab Test Solution, it will ease the examination
                                process as in India as we know due to lack of adequate infrastructure and non-
                                availability of the resources in remote areas it is impossible to conduct the
                                examinations but with the help of Tab Test Solution conduction of examination in these
                                areas becomes smooth and secured.</p>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>
    <section class="bg-color-red">
        <div class="container">
            <div class="row">
                <div class="bg-red-container">
                    <div class="col-lg-6  col-md-6 col-12 bg-content position-relative">
                        <p>Tablet Storage, Transportation, and Charging</p>
                        <img src="./img/red-tilt.png" alt="">
                    </div>

                    <div class="col-lg-6 col-md-6 col-12 tablet-img position-relative">
                        <img class="tab-img" src="./img/tablet.png" alt="">
                    </div>

                </div>
            </div>
        </div>
    </section>
    <section class="features">
        <div class="container">
            <div class="row mb-md-5 mb-0">
                <div class="features-head">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="overlay-content">
                           <p>An often-overlooked issue with tablets
                            is the mundane problems of long-term storage,transportation, and charging.
                            Initially, commercial charging stations and rack storage cabinetshas been investigated.</p>

                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="row  mt-md-3 mt-0">
                <div class="col-lg-7  col-12 offset-md-3 tagline justify-content-center d-flex mt-5">
                    <p>The exam itself has added features <span class="fw-bold" style="color:#bf1e2e;">to minimize
                            cheating like</span></p>
                </div>
            </div>
            <div class="row mt-70">
                <div class="col-lg-6 col-12 cut-girl position-relative text-center">
                    <img class="ring-img" src="./img/ring.png" alt="">
                    <img class="crop-girl-img" src="./img/crop-girl.png" alt="">
                </div>
                <div class="col-lg-6 col-12 position-relative">
                    <div class="arrow-section ">
                        <img class="red-arrow" src="./img/red-arrow.png" alt="">
                    </div>
                    <div class="features-section mt-70">
                        <div class="features-pt">
                            <div class="feature-icon"><img src="./img/feature-1.png" alt=""></div>
                            <div class="feature-content">
                                <p>Random problem order and</p>
                            </div>
                        </div>
                        <div class="features-pt">
                            <div class="feature-icon"><img src="./img/feature-2.png" alt=""></div>
                            <div class="feature-content">
                                <p>Random answer order.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
        </div>
    </section>
    <section class="padding">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-md-12  offset-xl-3">
                    <div class="pro-service-title text-center">
                        <h2 class="wow fadeInUp feat" >Features</h2>
                        <p class="wow fadeInUp mt-3">The new tablet-based system presented in this paper allows a number
                            of added security features, such as:</p>
                    </div>
                </div>
                <div class="col-md-12 position-relative">
                    <div class="pro-service-card-area mt-5">
                        <div class="single-pro-service-card one">
                            <div class="pro-service-card-text">
                                <h6>1.</h6>
                                <p>A single login per account</p>
                            </div>
                            <div class="pro-service-card-img service-card-icon-2 lightpink wow zoomIn"
                                data-wow-duration=".2s" data-wow-duration=".2s">
                                <img src="img/icon/1.png" class="maxh-40" alt="service">
                            </div>
                        </div>
                        <div class="single-pro-service-card two">
                            <div class="pro-service-card-text">
                                <h6>2.</h6>
                                <p>Real-time monitoring of studentduring exam</p>
                            </div>
                            <div class="pro-service-card-img service-card-icon-2 lightblue wow zoomIn"
                                data-wow-duration=".3s" data-wow-duration=".3s">
                                <img src="img/icon/2.png" class="maxh-40" alt="service">
                            </div>
                        </div>
                        <div class="single-pro-service-card three">
                            <div class="pro-service-card-text">
                                <h6>3.</h6>
                                <p>Restricting which tablets can be used through MAC address registration</p>
                            </div>
                            <div class="pro-service-card-img service-card-icon-2 purple wow zoomIn"
                                data-wow-duration=".4s" data-wow-duration=".4s">
                                <img src="img/icon/3.png" class="maxh-40" alt="service">

                            </div>
                        </div>
                        <div class="inner-circle-section">
                            <img src="img/center-logo.png" alt="center-img">
                        </div>
                        <div class="single-pro-service-card four">
                            <div class="pro-service-card-text">
                                <h6>4.</h6>
                                <p>Control of test app distribution</p>
                            </div>
                            <div class="pro-service-card-img service-card-icon-2 cyan wow zoomIn"
                                data-wow-duration=".5s" data-wow-duration=".5s">
                                <img src="img/icon/4.png" class="maxh-40" alt="service">

                            </div>
                        </div>
                        <div class="single-pro-service-card five">
                            <div class="pro-service-card-text">
                                <h6>5.</h6>
                                <p>IP address access control, and </p>
                            </div>
                            <div class="pro-service-card-img service-card-icon-2 orange wow zoomIn"
                                data-wow-duration=".2s" data-wow-duration=".2s">
                                <img src="img/icon/5.png" class="maxh-40" alt="service">

                            </div>
                        </div>

                        <div class="single-pro-service-card six">
                            <div class="pro-service-card-text">
                                <h6>6.</h6>
                                <p>Even forced removal of a student from thetest if needed. </p>
                            </div>
                            <div class="pro-service-card-img service-card-icon-2 darkpink wow zoomIn"
                                data-wow-duration=".3s" data-wow-duration=".3s">
                                <img src="img/icon/6.png" class="maxh-40" alt="service">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class=" border-bottom mt-md-4">
        <div class="container-fluid text-center">
            <h6 class="clientsUnit">Unite with <span><strong>1000+</strong></span> Happy Customers</h6>

            <div class="row">
                <div class="col-md-12">
                    <div class="clogo_slider owl-carousel owl-theme mt-3">
                        <div class="product-wrap">
                            <img src="img/microsoft.png" alt="" />
                        </div>
                        <div class="product-wrap">
                            <img src="img/amazon.png" alt="" />
                        </div>
                        <div class="product-wrap">
                            <img src="img/samsung.png" alt="" />
                        </div>
                        <div class="product-wrap">
                            <img src="img/microsoft.png" alt="" />
                        </div>
                        <div class="product-wrap">
                            <img src="img/amazon.png" alt="" />
                        </div>
                        <div class="product-wrap">
                            <img src="img/samsung.png" alt="" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- <section class="padding position-relative txt-center mt-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div style="max-width:550px">
                        <h2 class="wow fadeInUp">Introduction</h2>
                        <p class="wow fadeInUp mt-5">The technology of today gives opportunity to completely new ways of
                            developing examination systems for both examiner and students. Our TabTest solution is fully
                            customizable to suit our client need. We have a highly secured platform for conducting
                            Examinations.This solution is feasible for Entrance Exams, Recruitment Exams, Mock test,
                            Semester Exam etc. We provide End-to-End solution</p>
                        <p class="wow fadeInUp">Through our Tab Test Solution, it will ease the examination process as
                            in India as we know due to lack of adequate infrastructure and non- availability of the
                            resources in remote areas it is impossible to conduct the examinations but with the help of
                            Tab Test Solution conduction of examination in these areas becomes smooth and secured.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="image-shape-wrapper">
                        <img class="wow zoomIn" src="img/Introduction.jpg" alt="Introduction">
                    </div>
                </div>
            </div>
        </div>
       
    </section> -->







    <!-- <section class="padding text-center bg-student-exam">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <h2 class="wow fadeInUp">The exam itself has added features to minimize cheating like </h2>
                </div>
            </div>
            <div class="row mt-5 position-relative">
                <div class="col-lg-4 offset-lg-2 col-md-6">
                    <div class="Advantages-icon">
                        <img src="img/problem.png" alt="" />
                    </div>
                    <h5>1. Random problem order and </h5>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="Advantages-icon">
                        <img src="img/answer.png" alt="" />
                    </div>
                    <h5>2. Random answer order. </h5>
                </div>
            </div>
        </div>
    </section> -->


    <?php include 'footer.php';?>

    <script src="js/jquery-3.5.0.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/script.js"></script>
</body>

</html>