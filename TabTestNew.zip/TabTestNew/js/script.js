"use strict";

(function ($) {
  
  $('.clogo_slider').owlCarousel({
    loop:true,
    nav: false,
    dots: false,
    autoplay: true,
    autoplayTimeout: 30000,
    item: 7,
    margin:30,
    responsive: {
      0: {
        items: 2
      },
      399:{
        item:3
      },
      576: {
        items: 5
      },
      992: {
        items: 8
      }
    }
  });
    

  /*---animation wow js---*/
  new WOW().init();


})(jQuery);