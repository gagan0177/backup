
<header>
  <nav class="navbar navbar-expand-lg navbar-light bg-transparent">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php">
        <img width="170" src="img/logo.svg" alt="" />
      </a>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav links-nav">
          <li class="nav-item">
            <a class="nav-link active" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Features</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Advantages</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact Us</a>
          </li>
        </ul>
        <div class="donate-btn desk">
          <a href="#" class="help_button">Book a Demo</a>
        </div>
      </div>
      <div class="donate-btn ms-auto d-block d-sm-none">
          <a href="#" class="help_button Onmobile">Request a Demo</a>
        </div>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
        aria-label="Toggle navigation">
        <div class="phone-nav" id="phone-nav">
          <div></div>
        </div>
      </button>
    </div>
  </nav>
</header>