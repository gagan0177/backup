<footer>
  <div class="container">
    <div class="row">
    <div class="col-md-4">
        <div class=" address_info_f">
          <img src="img/white-logo.png" width="200">
          <p class="mt-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
          <p class="mt-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
        </div>
      </div>
      <div class="col-md-3">
        <h4>Important Links</h4>
        <ul>
          <li><a href="#">Terms & Conditions</a></li>
          <li><a href="#">Privacy Policy</a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">Features</a></li>
          <li><a href="#">Advantages</a></li>
          <li><a href="#">Contact Us</a></li>
        </ul>
      </div>
      <div class="col-md-2">
        <h4>Office</h4>
        <ul>
          <li><a href="#">Tabtest.</a></li>
          <li><a href="mailto">Email- info@gmail.com</a></li>
          <li><a href="tel:+(406) 555-0120">Mob- +(406) 555-0120</a></li>
          
        </ul>
        <!-- <div class="address_info_f">
          <p><a href="tel:+(406) 555-0120">+(406) 555-0120</a></p>
          <p><a href="mailto">info@gmail.com</a></p>
        </div> -->
      </div>
      
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <p class="wow fadeInUp">© 2022 TabTest. All rights reserved.</p>
    </div>
  </div>
</footer>